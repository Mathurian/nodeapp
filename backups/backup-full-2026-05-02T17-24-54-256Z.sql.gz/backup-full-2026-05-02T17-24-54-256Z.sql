--
-- PostgreSQL database dump
--

\restrict APHSQtNhBEQ7ZH5xapzdYwctPOtCEEVjaJqFzl1P9odjTONZtWpJBDdjYI6EA2c

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = on;

--
-- Name: AssignmentStatus; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."AssignmentStatus" AS ENUM (
    'PENDING',
    'ACTIVE',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."AssignmentStatus" OWNER TO event_manager;

--
-- Name: BackupFrequency; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."BackupFrequency" AS ENUM (
    'MINUTES',
    'HOURS',
    'DAILY',
    'WEEKLY',
    'MONTHLY'
);


ALTER TYPE public."BackupFrequency" OWNER TO event_manager;

--
-- Name: BackupStatus; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."BackupStatus" AS ENUM (
    'SUCCESS',
    'FAILED',
    'IN_PROGRESS'
);


ALTER TYPE public."BackupStatus" OWNER TO event_manager;

--
-- Name: BackupType; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."BackupType" AS ENUM (
    'SCHEMA',
    'FULL',
    'SCHEDULED'
);


ALTER TYPE public."BackupType" OWNER TO event_manager;

--
-- Name: CertificationStatus; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."CertificationStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'CERTIFIED',
    'REJECTED'
);


ALTER TYPE public."CertificationStatus" OWNER TO event_manager;

--
-- Name: ContestantNumberingMode; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."ContestantNumberingMode" AS ENUM (
    'MANUAL',
    'AUTO_INDEXED',
    'OPTIONAL'
);


ALTER TYPE public."ContestantNumberingMode" OWNER TO event_manager;

--
-- Name: CustomFieldType; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."CustomFieldType" AS ENUM (
    'TEXT',
    'TEXT_AREA',
    'NUMBER',
    'DATE',
    'BOOLEAN',
    'SELECT',
    'MULTI_SELECT',
    'EMAIL',
    'URL',
    'PHONE'
);


ALTER TYPE public."CustomFieldType" OWNER TO event_manager;

--
-- Name: DeductionStatus; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."DeductionStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."DeductionStatus" OWNER TO event_manager;

--
-- Name: EmailStatus; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."EmailStatus" AS ENUM (
    'PENDING',
    'SENT',
    'FAILED',
    'QUEUED',
    'BOUNCED',
    'DELIVERED'
);


ALTER TYPE public."EmailStatus" OWNER TO event_manager;

--
-- Name: FileCategory; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."FileCategory" AS ENUM (
    'CONTESTANT_IMAGE',
    'JUDGE_IMAGE',
    'DOCUMENT',
    'TEMPLATE',
    'REPORT',
    'BACKUP',
    'OTHER'
);


ALTER TYPE public."FileCategory" OWNER TO event_manager;

--
-- Name: IdempotencyActorType; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."IdempotencyActorType" AS ENUM (
    'USER',
    'SERVICE',
    'SYSTEM'
);


ALTER TYPE public."IdempotencyActorType" OWNER TO event_manager;

--
-- Name: IdempotencyStatus; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."IdempotencyStatus" AS ENUM (
    'PENDING',
    'COMPLETED',
    'FAILED_RETRYABLE',
    'FAILED_TERMINAL'
);


ALTER TYPE public."IdempotencyStatus" OWNER TO event_manager;

--
-- Name: LogLevel; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."LogLevel" AS ENUM (
    'ERROR',
    'WARN',
    'INFO',
    'DEBUG'
);


ALTER TYPE public."LogLevel" OWNER TO event_manager;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."NotificationType" AS ENUM (
    'INFO',
    'SUCCESS',
    'WARNING',
    'ERROR',
    'SYSTEM'
);


ALTER TYPE public."NotificationType" OWNER TO event_manager;

--
-- Name: RequestStatus; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."RequestStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."RequestStatus" OWNER TO event_manager;

--
-- Name: ScoringType; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."ScoringType" AS ENUM (
    'STRAIGHT',
    'OLYMPIC'
);


ALTER TYPE public."ScoringType" OWNER TO event_manager;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: event_manager
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'ORGANIZER',
    'BOARD',
    'JUDGE',
    'CONTESTANT',
    'EMCEE',
    'TALLY_MASTER',
    'AUDITOR'
);


ALTER TYPE public."UserRole" OWNER TO event_manager;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.activity_logs (
    id text NOT NULL,
    "userId" text,
    "userName" text,
    "userRole" text,
    action text NOT NULL,
    "resourceType" text,
    "resourceId" text,
    "ipAddress" text,
    "userAgent" text,
    "logLevel" public."LogLevel" DEFAULT 'INFO'::public."LogLevel" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    details jsonb,
    "tenantId" text
);


ALTER TABLE public.activity_logs OWNER TO event_manager;

--
-- Name: archived_events; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.archived_events (
    id text NOT NULL,
    "eventId" text NOT NULL,
    name text NOT NULL,
    description text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "archivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "archivedById" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.archived_events OWNER TO event_manager;

--
-- Name: assignments; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.assignments (
    id text NOT NULL,
    "judgeId" text NOT NULL,
    "categoryId" text,
    "contestId" text NOT NULL,
    "eventId" text NOT NULL,
    status public."AssignmentStatus" DEFAULT 'PENDING'::public."AssignmentStatus" NOT NULL,
    "assignedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "assignedBy" text NOT NULL,
    notes text,
    priority integer DEFAULT 1 NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.assignments OWNER TO event_manager;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "userId" text,
    "userName" text,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text,
    changes jsonb,
    "ipAddress" text,
    "userAgent" text,
    metadata jsonb,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO event_manager;

--
-- Name: auditor_assignments; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.auditor_assignments (
    id text NOT NULL,
    "userId" text NOT NULL,
    "categoryId" text,
    "contestId" text,
    "eventId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "assignedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "assignedBy" text,
    notes text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.auditor_assignments OWNER TO event_manager;

--
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.backup_logs (
    id text NOT NULL,
    location text DEFAULT ''::text NOT NULL,
    size bigint,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "errorMessage" text,
    type text DEFAULT 'full'::text NOT NULL,
    status text DEFAULT 'success'::text NOT NULL,
    "tenantId" text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    duration integer,
    metadata jsonb
);


ALTER TABLE public.backup_logs OWNER TO event_manager;

--
-- Name: backup_schedules; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.backup_schedules (
    id text NOT NULL,
    "tenantId" text,
    name text NOT NULL,
    "backupType" text DEFAULT 'full'::text NOT NULL,
    frequency text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "retentionDays" integer DEFAULT 30 NOT NULL,
    "nextRunAt" timestamp(3) without time zone,
    "lastRunAt" timestamp(3) without time zone,
    "lastStatus" text DEFAULT 'pending'::text,
    targets jsonb DEFAULT '[]'::jsonb NOT NULL,
    compression boolean DEFAULT true NOT NULL,
    encryption boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.backup_schedules OWNER TO event_manager;

--
-- Name: backup_settings; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.backup_settings (
    id text NOT NULL,
    "retentionDays" integer DEFAULT 30 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "backupType" text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    frequency text NOT NULL,
    "frequencyValue" integer
);


ALTER TABLE public.backup_settings OWNER TO event_manager;

--
-- Name: backup_targets; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.backup_targets (
    id text NOT NULL,
    "tenantId" text,
    name text NOT NULL,
    type text NOT NULL,
    config jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "lastVerified" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.backup_targets OWNER TO event_manager;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.categories (
    id text NOT NULL,
    "contestId" text NOT NULL,
    name text NOT NULL,
    description text,
    "scoreCap" integer,
    "timeLimit" integer,
    "contestantMin" integer,
    "contestantMax" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "totalsCertified" boolean DEFAULT false NOT NULL,
    "tenantId" text NOT NULL,
    "boardApproved" boolean DEFAULT false NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "approvedBy" text,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" text
);


ALTER TABLE public.categories OWNER TO event_manager;

--
-- Name: category_certifications; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.category_certifications (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    role text NOT NULL,
    "userId" text NOT NULL,
    "signatureName" text,
    "boardRoleSnapshot" text,
    "certifiedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.category_certifications OWNER TO event_manager;

--
-- Name: category_contestants; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.category_contestants (
    "categoryId" text NOT NULL,
    "contestantId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.category_contestants OWNER TO event_manager;

--
-- Name: category_judges; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.category_judges (
    "categoryId" text NOT NULL,
    "judgeId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.category_judges OWNER TO event_manager;

--
-- Name: category_templates; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.category_templates (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.category_templates OWNER TO event_manager;

--
-- Name: category_types; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.category_types (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "isSystem" boolean DEFAULT false NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.category_types OWNER TO event_manager;

--
-- Name: certifications; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.certifications (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "contestId" text NOT NULL,
    "eventId" text NOT NULL,
    "userId" text,
    status public."CertificationStatus" DEFAULT 'PENDING'::public."CertificationStatus" NOT NULL,
    "currentStep" integer DEFAULT 1 NOT NULL,
    "totalSteps" integer DEFAULT 4 NOT NULL,
    "judgeCertified" boolean DEFAULT false NOT NULL,
    "tallyCertified" boolean DEFAULT false NOT NULL,
    "auditorCertified" boolean DEFAULT false NOT NULL,
    "boardApproved" boolean DEFAULT false NOT NULL,
    "certifiedAt" timestamp(3) without time zone,
    "certifiedBy" text,
    "rejectionReason" text,
    comments text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.certifications OWNER TO event_manager;

--
-- Name: contest_certifications; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.contest_certifications (
    id text NOT NULL,
    "contestId" text NOT NULL,
    role text NOT NULL,
    "userId" text NOT NULL,
    "boardRoleSnapshot" text,
    "certifiedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.contest_certifications OWNER TO event_manager;

--
-- Name: contest_contestants; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.contest_contestants (
    "contestId" text NOT NULL,
    "contestantId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.contest_contestants OWNER TO event_manager;

--
-- Name: contest_judges; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.contest_judges (
    "contestId" text NOT NULL,
    "judgeId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.contest_judges OWNER TO event_manager;

--
-- Name: contestants; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.contestants (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    gender text,
    pronouns text,
    "contestantNumber" integer,
    bio text,
    "imagePath" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.contestants OWNER TO event_manager;

--
-- Name: contests; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.contests (
    id text NOT NULL,
    "eventId" text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "contestantNumberingMode" public."ContestantNumberingMode" DEFAULT 'MANUAL'::public."ContestantNumberingMode" NOT NULL,
    "nextContestantNumber" integer DEFAULT 1,
    archived boolean DEFAULT false NOT NULL,
    "contestantViewRestricted" boolean DEFAULT false NOT NULL,
    "contestantViewReleaseDate" timestamp(3) without time zone,
    "isLocked" boolean DEFAULT false NOT NULL,
    "lockedAt" timestamp(3) without time zone,
    "lockVerifiedBy" text,
    "scoringType" public."ScoringType",
    "tenantId" text NOT NULL,
    "winnersPublished" boolean DEFAULT false NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "publishedBy" text,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" text
);


ALTER TABLE public.contests OWNER TO event_manager;

--
-- Name: criteria; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.criteria (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    name text NOT NULL,
    "maxScore" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.criteria OWNER TO event_manager;

--
-- Name: custom_field_values; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.custom_field_values (
    id text NOT NULL,
    "customFieldId" text NOT NULL,
    "entityId" text NOT NULL,
    value text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.custom_field_values OWNER TO event_manager;

--
-- Name: custom_fields; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.custom_fields (
    id text NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    type public."CustomFieldType" NOT NULL,
    "entityType" text NOT NULL,
    required boolean DEFAULT false NOT NULL,
    "defaultValue" text,
    options jsonb,
    validation jsonb,
    "order" integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.custom_fields OWNER TO event_manager;

--
-- Name: deduction_approvals; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.deduction_approvals (
    id text NOT NULL,
    "requestId" text NOT NULL,
    "approvedById" text NOT NULL,
    role text NOT NULL,
    "boardRoleSnapshot" text,
    "isHeadJudge" boolean DEFAULT false NOT NULL,
    "approvedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.deduction_approvals OWNER TO event_manager;

--
-- Name: deduction_requests; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.deduction_requests (
    id text NOT NULL,
    "contestantId" text NOT NULL,
    "categoryId" text NOT NULL,
    amount double precision NOT NULL,
    reason text NOT NULL,
    "requestedById" text,
    status public."DeductionStatus" DEFAULT 'PENDING'::public."DeductionStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.deduction_requests OWNER TO event_manager;

--
-- Name: dr_configs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.dr_configs (
    id text NOT NULL,
    "tenantId" text,
    "backupFrequency" text DEFAULT 'daily'::text NOT NULL,
    "backupRetentionDays" integer DEFAULT 30 NOT NULL,
    "enableAutoBackup" boolean DEFAULT true NOT NULL,
    "enablePITR" boolean DEFAULT false NOT NULL,
    "enableDRTesting" boolean DEFAULT true NOT NULL,
    "drTestFrequency" text DEFAULT 'weekly'::text NOT NULL,
    "backupLocations" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "rtoMinutes" integer DEFAULT 240 NOT NULL,
    "rpoMinutes" integer DEFAULT 60 NOT NULL,
    "alertEmail" text,
    "enableFailover" boolean DEFAULT false NOT NULL,
    "healthCheckInterval" integer DEFAULT 5 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.dr_configs OWNER TO event_manager;

--
-- Name: dr_metrics; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.dr_metrics (
    id text NOT NULL,
    "tenantId" text,
    "metricType" text NOT NULL,
    value double precision NOT NULL,
    unit text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb
);


ALTER TABLE public.dr_metrics OWNER TO event_manager;

--
-- Name: dr_test_logs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.dr_test_logs (
    id text NOT NULL,
    "tenantId" text,
    "testType" text DEFAULT 'restore'::text NOT NULL,
    "backupId" text,
    status text DEFAULT 'running'::text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    duration integer,
    "testResults" jsonb,
    "errorMessage" text,
    "automatedTest" boolean DEFAULT true NOT NULL,
    "testedBy" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.dr_test_logs OWNER TO event_manager;

--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.email_logs (
    id text NOT NULL,
    "to" text NOT NULL,
    "from" text,
    subject text NOT NULL,
    template text,
    status text DEFAULT 'pending'::text NOT NULL,
    "messageId" text,
    "errorMessage" text,
    "sentAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text,
    "userId" text,
    metadata jsonb
);


ALTER TABLE public.email_logs OWNER TO event_manager;

--
-- Name: email_settings; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.email_settings (
    id text NOT NULL,
    "smtpHost" text,
    "smtpPort" integer DEFAULT 587 NOT NULL,
    "smtpSecure" boolean DEFAULT false NOT NULL,
    "smtpUser" text,
    "smtpPassword" text,
    "fromEmail" text,
    "fromName" text,
    "enableEmail" boolean DEFAULT false NOT NULL,
    "enableNotifications" boolean DEFAULT true NOT NULL,
    "enableReports" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.email_settings OWNER TO event_manager;

--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.email_templates (
    id text NOT NULL,
    name text,
    subject text,
    body text,
    type text DEFAULT 'CUSTOM'::text,
    "eventId" text,
    variables text,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "headerHtml" text,
    "footerHtml" text,
    "logoUrl" text,
    "logoPosition" text,
    "backgroundColor" text,
    "primaryColor" text,
    "textColor" text,
    "fontFamily" text,
    "fontSize" text,
    "layoutType" text,
    "contentWrapper" text,
    "borderStyle" text,
    "borderColor" text,
    "borderWidth" text,
    "borderRadius" text,
    padding text,
    margin text,
    "templateData" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.email_templates OWNER TO event_manager;

--
-- Name: emcee_scripts; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.emcee_scripts (
    id text NOT NULL,
    "eventId" text,
    "contestId" text,
    "categoryId" text,
    title text NOT NULL,
    content text NOT NULL,
    "order" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    file_path text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.emcee_scripts OWNER TO event_manager;

--
-- Name: error_logs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.error_logs (
    id text NOT NULL,
    message text NOT NULL,
    stack text,
    level public."LogLevel" DEFAULT 'ERROR'::public."LogLevel" NOT NULL,
    context text,
    "userId" text,
    path text,
    method text,
    "statusCode" integer,
    metadata jsonb,
    resolved boolean DEFAULT false NOT NULL,
    "resolvedAt" timestamp(3) without time zone,
    "resolvedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text
);


ALTER TABLE public.error_logs OWNER TO event_manager;

--
-- Name: event_logs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.event_logs (
    id text NOT NULL,
    "tenantId" text,
    "eventType" text NOT NULL,
    "entityType" text,
    "entityId" text,
    payload jsonb NOT NULL,
    "userId" text,
    source text DEFAULT 'system'::text NOT NULL,
    "correlationId" text,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    processed boolean DEFAULT false NOT NULL,
    "processedAt" timestamp(3) without time zone,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "lastError" text,
    metadata jsonb
);


ALTER TABLE public.event_logs OWNER TO event_manager;

--
-- Name: event_templates; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.event_templates (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    contests jsonb NOT NULL,
    categories jsonb NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.event_templates OWNER TO event_manager;

--
-- Name: events; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.events (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    location text,
    "maxContestants" integer,
    "contestantNumberingMode" public."ContestantNumberingMode" DEFAULT 'MANUAL'::public."ContestantNumberingMode" NOT NULL,
    "contestantViewRestricted" boolean DEFAULT false NOT NULL,
    "isLocked" boolean DEFAULT false NOT NULL,
    "contestantViewReleaseDate" timestamp(3) without time zone,
    "lockedAt" timestamp(3) without time zone,
    "lockVerifiedBy" text,
    "scoringType" public."ScoringType",
    "requireAllTallyCertifiers" boolean,
    "requireAllAuditorCertifiers" boolean,
    "tenantId" text NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" text
);


ALTER TABLE public.events OWNER TO event_manager;

--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.feature_flags (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    enabled boolean DEFAULT false NOT NULL,
    strategy text DEFAULT 'OFF'::text NOT NULL,
    percentage integer,
    "userIds" text[],
    "tenantIds" text[],
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "targetPercentage" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    "updatedBy" text
);


ALTER TABLE public.feature_flags OWNER TO event_manager;

--
-- Name: files; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.files (
    id text NOT NULL,
    filename text NOT NULL,
    "originalName" text NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    path text NOT NULL,
    category public."FileCategory" NOT NULL,
    "uploadedBy" text NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    metadata text,
    checksum text,
    "eventId" text,
    "contestId" text,
    "categoryId" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.files OWNER TO event_manager;

--
-- Name: idempotency_records; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.idempotency_records (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "actorType" public."IdempotencyActorType" NOT NULL,
    "actorId" text NOT NULL,
    method text NOT NULL,
    path text NOT NULL,
    "canonicalPath" text NOT NULL,
    key text NOT NULL,
    "requestHash" text NOT NULL,
    status public."IdempotencyStatus" NOT NULL,
    "statusCode" integer,
    "errorCode" text,
    "responseBody" jsonb,
    digest text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "leaseExpiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastSeenAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.idempotency_records OWNER TO event_manager;

--
-- Name: judge_certifications; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.judge_certifications (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "judgeId" text NOT NULL,
    "signatureName" text NOT NULL,
    "certifiedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.judge_certifications OWNER TO event_manager;

--
-- Name: judge_comments; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.judge_comments (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "contestantId" text NOT NULL,
    "judgeId" text NOT NULL,
    comment text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.judge_comments OWNER TO event_manager;

--
-- Name: judge_contestant_certifications; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.judge_contestant_certifications (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "judgeId" text NOT NULL,
    "contestantId" text NOT NULL,
    "certifiedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.judge_contestant_certifications OWNER TO event_manager;

--
-- Name: judge_score_removal_requests; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.judge_score_removal_requests (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "contestantId" text NOT NULL,
    "judgeId" text NOT NULL,
    "scoreId" text,
    reason text NOT NULL,
    status public."RequestStatus" DEFAULT 'PENDING'::public."RequestStatus" NOT NULL,
    "requestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "reviewedAt" timestamp(3) without time zone,
    "reviewedById" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.judge_score_removal_requests OWNER TO event_manager;

--
-- Name: judge_uncertification_requests; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.judge_uncertification_requests (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "judgeId" text NOT NULL,
    reason text NOT NULL,
    "requestedBy" text,
    "requestedByBoardRoleSnapshot" text,
    "requestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "approvedBy" text,
    "approvedByBoardRoleSnapshot" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectedBy" text,
    "rejectedByBoardRoleSnapshot" text,
    "rejectedAt" timestamp(3) without time zone,
    "rejectionReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    status public."RequestStatus" DEFAULT 'PENDING'::public."RequestStatus" NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.judge_uncertification_requests OWNER TO event_manager;

--
-- Name: judges; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.judges (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    gender text,
    pronouns text,
    bio text,
    "imagePath" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isHeadJudge" boolean DEFAULT false NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.judges OWNER TO event_manager;

--
-- Name: logging_settings; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.logging_settings (
    id text NOT NULL,
    level public."LogLevel" DEFAULT 'INFO'::public."LogLevel" NOT NULL,
    "enableAudit" boolean DEFAULT true NOT NULL,
    "enableActivity" boolean DEFAULT true NOT NULL,
    "enableError" boolean DEFAULT true NOT NULL,
    "maxLogAge" integer DEFAULT 30 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.logging_settings OWNER TO event_manager;

--
-- Name: notification_digests; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.notification_digests (
    id text NOT NULL,
    "userId" text NOT NULL,
    frequency text NOT NULL,
    "lastSentAt" timestamp(3) without time zone,
    "nextSendAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.notification_digests OWNER TO event_manager;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.notification_preferences (
    id text NOT NULL,
    "userId" text NOT NULL,
    "emailEnabled" boolean DEFAULT true NOT NULL,
    "pushEnabled" boolean DEFAULT true NOT NULL,
    "inAppEnabled" boolean DEFAULT true NOT NULL,
    "emailDigestFrequency" text DEFAULT 'daily'::text NOT NULL,
    "emailTypes" text,
    "pushTypes" text,
    "inAppTypes" text,
    "quietHoursStart" text,
    "quietHoursEnd" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO event_manager;

--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.notification_templates (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    "emailSubject" text,
    "emailBody" text,
    variables text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.notification_templates OWNER TO event_manager;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "userId" text NOT NULL,
    type public."NotificationType" DEFAULT 'INFO'::public."NotificationType" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    link text,
    read boolean DEFAULT false NOT NULL,
    "readAt" timestamp(3) without time zone,
    metadata text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    "emailSent" boolean DEFAULT false NOT NULL,
    "emailSentAt" timestamp(3) without time zone,
    "pushSent" boolean DEFAULT false NOT NULL,
    "pushSentAt" timestamp(3) without time zone,
    "templateId" text,
    "sentBy" text,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.notifications OWNER TO event_manager;

--
-- Name: overall_deductions; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.overall_deductions (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "contestantId" text NOT NULL,
    deduction double precision NOT NULL,
    reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.overall_deductions OWNER TO event_manager;

--
-- Name: password_histories; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.password_histories (
    id text NOT NULL,
    "userId" text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_histories OWNER TO event_manager;

--
-- Name: password_policies; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.password_policies (
    id text NOT NULL,
    "minLength" integer DEFAULT 8 NOT NULL,
    "requireUppercase" boolean DEFAULT true NOT NULL,
    "requireLowercase" boolean DEFAULT true NOT NULL,
    "requireNumbers" boolean DEFAULT true NOT NULL,
    "requireSpecialChars" boolean DEFAULT true NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.password_policies OWNER TO event_manager;

--
-- Name: performance_logs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.performance_logs (
    id text NOT NULL,
    endpoint text NOT NULL,
    method text NOT NULL,
    "responseTime" integer NOT NULL,
    "statusCode" integer NOT NULL,
    "userId" text,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "eventId" text,
    "contestId" text,
    "categoryId" text
);


ALTER TABLE public.performance_logs OWNER TO event_manager;

--
-- Name: permission_audit_logs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.permission_audit_logs (
    id text NOT NULL,
    role public."UserRole" NOT NULL,
    resource text NOT NULL,
    operation text NOT NULL,
    "previousVal" boolean,
    "newVal" boolean NOT NULL,
    "changedBy" text NOT NULL,
    "changedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    reason text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.permission_audit_logs OWNER TO event_manager;

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.push_subscriptions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    "expirationTime" timestamp(3) without time zone,
    "userAgent" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastUsedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.push_subscriptions OWNER TO event_manager;

--
-- Name: rate_limit_configs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.rate_limit_configs (
    id text NOT NULL,
    name text NOT NULL,
    tier text,
    "tenantId" text,
    "userId" text,
    endpoint text,
    "requestsPerHour" integer DEFAULT 1000 NOT NULL,
    "requestsPerMinute" integer DEFAULT 50 NOT NULL,
    "burstLimit" integer DEFAULT 100 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    "updatedBy" text
);


ALTER TABLE public.rate_limit_configs OWNER TO event_manager;

--
-- Name: report_instances; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.report_instances (
    id text NOT NULL,
    "templateId" text DEFAULT 'default'::text,
    "generatedById" text,
    "generatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    data text,
    format text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.report_instances OWNER TO event_manager;

--
-- Name: report_templates; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.report_templates (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    template text NOT NULL,
    parameters text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.report_templates OWNER TO event_manager;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.reports (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    parameters text NOT NULL,
    format text NOT NULL,
    "generatedBy" text NOT NULL,
    "filePath" text,
    "fileSize" integer,
    status text DEFAULT 'GENERATED'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.reports OWNER TO event_manager;

--
-- Name: review_contestant_certifications; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.review_contestant_certifications (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "contestantId" text NOT NULL,
    "reviewedBy" text,
    "reviewerRole" text NOT NULL,
    "reviewedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.review_contestant_certifications OWNER TO event_manager;

--
-- Name: review_judge_score_certifications; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.review_judge_score_certifications (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "judgeId" text NOT NULL,
    "reviewedBy" text,
    "reviewerRole" text NOT NULL,
    "reviewedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.review_judge_score_certifications OWNER TO event_manager;

--
-- Name: role_assignments; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.role_assignments (
    id text NOT NULL,
    "userId" text NOT NULL,
    role text NOT NULL,
    "contestId" text,
    "eventId" text,
    "categoryId" text,
    "assignedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "assignedBy" text,
    notes text,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.role_assignments OWNER TO event_manager;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.role_permissions (
    id text NOT NULL,
    role public."UserRole" NOT NULL,
    resource text NOT NULL,
    operation text NOT NULL,
    allowed boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO event_manager;

--
-- Name: saved_searches; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.saved_searches (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    query text NOT NULL,
    filters text,
    "entityTypes" text,
    "isPublic" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.saved_searches OWNER TO event_manager;

--
-- Name: score_comments; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.score_comments (
    id text NOT NULL,
    "scoreId" text NOT NULL,
    "criterionId" text NOT NULL,
    "contestantId" text NOT NULL,
    "judgeId" text NOT NULL,
    comment text NOT NULL,
    "isPrivate" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.score_comments OWNER TO event_manager;

--
-- Name: score_files; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.score_files (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "judgeId" text NOT NULL,
    "contestantId" text,
    "fileName" text NOT NULL,
    "fileType" text NOT NULL,
    "filePath" text NOT NULL,
    "fileSize" integer NOT NULL,
    "uploadedById" text,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.score_files OWNER TO event_manager;

--
-- Name: score_governance_approvals; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.score_governance_approvals (
    id text NOT NULL,
    "requestId" text NOT NULL,
    "approvedById" text NOT NULL,
    "approverRole" text NOT NULL,
    "approverBoardRoleSnapshot" text,
    "typedSignature" text,
    "drawnSignatureData" text,
    "signatureFilePath" text,
    "approvedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.score_governance_approvals OWNER TO event_manager;

--
-- Name: score_governance_requests; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.score_governance_requests (
    id text NOT NULL,
    "actionType" text NOT NULL,
    "scopeType" text NOT NULL,
    "targetCertificationLevel" text,
    "eventId" text,
    "contestId" text,
    "categoryId" text,
    "contestantId" text,
    "judgeId" text,
    "scoreId" text,
    reason text NOT NULL,
    status public."RequestStatus" DEFAULT 'PENDING'::public."RequestStatus" NOT NULL,
    "requestedById" text NOT NULL,
    "requesterRole" text NOT NULL,
    "requesterBoardRoleSnapshot" text,
    "initiatorTypedSignature" text,
    "initiatorDrawnSignatureData" text,
    "initiatorSignatureFilePath" text,
    "requiredAdditionalApprovals" integer DEFAULT 2 NOT NULL,
    "executedAt" timestamp(3) without time zone,
    "executedById" text,
    "executionSummary" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.score_governance_requests OWNER TO event_manager;

--
-- Name: score_removal_requests; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.score_removal_requests (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "judgeId" text NOT NULL,
    reason text NOT NULL,
    status public."RequestStatus" DEFAULT 'PENDING'::public."RequestStatus" NOT NULL,
    "requestedBy" text,
    "requestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tallySignature" text,
    "tallySignedAt" timestamp(3) without time zone,
    "tallySignedBy" text,
    "auditorSignature" text,
    "auditorSignedAt" timestamp(3) without time zone,
    "auditorSignedBy" text,
    "boardSignature" text,
    "boardRoleSnapshot" text,
    "boardSignedAt" timestamp(3) without time zone,
    "boardSignedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.score_removal_requests OWNER TO event_manager;

--
-- Name: scores; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.scores (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "contestantId" text NOT NULL,
    "judgeId" text NOT NULL,
    "criterionId" text,
    score integer,
    deduction integer DEFAULT 0,
    "deductionReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "allowCommentEdit" boolean DEFAULT true NOT NULL,
    "certifiedAt" timestamp(3) without time zone,
    "certifiedBy" text,
    comment text,
    "isCertified" boolean DEFAULT false NOT NULL,
    "isLocked" boolean DEFAULT false NOT NULL,
    "lockedAt" timestamp(3) without time zone,
    "lockedBy" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.scores OWNER TO event_manager;

--
-- Name: search_analytics; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.search_analytics (
    id text NOT NULL,
    query text NOT NULL,
    "resultCount" integer NOT NULL,
    "avgResponseTime" integer NOT NULL,
    "searchCount" integer DEFAULT 1 NOT NULL,
    "lastSearched" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.search_analytics OWNER TO event_manager;

--
-- Name: search_history; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.search_history (
    id text NOT NULL,
    "userId" text NOT NULL,
    query text NOT NULL,
    filters text,
    "entityTypes" text,
    "resultCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.search_history OWNER TO event_manager;

--
-- Name: security_settings; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.security_settings (
    id text NOT NULL,
    "passwordMinLength" integer DEFAULT 8 NOT NULL,
    "passwordRequireUppercase" boolean DEFAULT true NOT NULL,
    "passwordRequireLowercase" boolean DEFAULT true NOT NULL,
    "passwordRequireNumbers" boolean DEFAULT true NOT NULL,
    "passwordRequireSymbols" boolean DEFAULT false NOT NULL,
    "passwordExpiryDays" integer DEFAULT 90 NOT NULL,
    "maxLoginAttempts" integer DEFAULT 5 NOT NULL,
    "lockoutDurationMinutes" integer DEFAULT 30 NOT NULL,
    "requireTwoFactor" boolean DEFAULT false NOT NULL,
    "sessionTimeoutMinutes" integer DEFAULT 480 NOT NULL,
    "enableIpWhitelist" boolean DEFAULT false NOT NULL,
    "allowedIps" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.security_settings OWNER TO event_manager;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.system_settings (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    description text,
    category text,
    "tenantId" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "updatedBy" text
);


ALTER TABLE public.system_settings OWNER TO event_manager;

--
-- Name: tally_master_assignments; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.tally_master_assignments (
    id text NOT NULL,
    "userId" text NOT NULL,
    "categoryId" text,
    "contestId" text,
    "eventId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "assignedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "assignedBy" text,
    notes text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.tally_master_assignments OWNER TO event_manager;

--
-- Name: template_criteria; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.template_criteria (
    id text NOT NULL,
    "templateId" text NOT NULL,
    name text NOT NULL,
    "maxScore" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.template_criteria OWNER TO event_manager;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    domain text,
    "isActive" boolean DEFAULT true NOT NULL,
    settings jsonb,
    "maxUsers" integer,
    "maxEvents" integer,
    "maxStorage" bigint,
    "planType" text DEFAULT 'free'::text NOT NULL,
    "subscriptionStatus" text DEFAULT 'active'::text NOT NULL,
    "subscriptionEndsAt" timestamp(3) without time zone,
    "scoringType" public."ScoringType" DEFAULT 'STRAIGHT'::public."ScoringType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO event_manager;

--
-- Name: theme_settings; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.theme_settings (
    id text NOT NULL,
    "primaryColor" text DEFAULT '#2563eb'::text NOT NULL,
    "secondaryColor" text DEFAULT '#1e40af'::text NOT NULL,
    "logoPath" text,
    "faviconPath" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.theme_settings OWNER TO event_manager;

--
-- Name: user_field_configurations; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.user_field_configurations (
    id text NOT NULL,
    "fieldName" text NOT NULL,
    "isVisible" boolean DEFAULT true NOT NULL,
    "isRequired" boolean DEFAULT false NOT NULL,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_field_configurations OWNER TO event_manager;

--
-- Name: users; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text NOT NULL,
    "preferredName" text,
    email text NOT NULL,
    password text NOT NULL,
    role public."UserRole" NOT NULL,
    "boardRole" text,
    gender text,
    pronouns text,
    "judgeId" text,
    "contestantId" text,
    "sessionVersion" integer DEFAULT 1 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    "judgeBio" text,
    "judgeSpecialties" text,
    "judgeCertifications" text,
    "contestantBio" text,
    "contestantNumber" text,
    "contestantAge" integer,
    "contestantSchool" text,
    bio text,
    "imagePath" text,
    phone text,
    address text,
    timezone text DEFAULT 'UTC'::text,
    language text DEFAULT 'en'::text,
    "notificationSettings" text,
    "smsPhone" text,
    "smsEnabled" boolean DEFAULT false NOT NULL,
    privacy text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "navigationPreferences" jsonb,
    city text,
    state text,
    country text,
    "tenantId" text NOT NULL,
    "isSuperAdmin" boolean DEFAULT false NOT NULL,
    "mfaBackupCodes" text,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaEnrolledAt" timestamp(3) without time zone,
    "mfaMethod" text DEFAULT 'totp'::text,
    "mfaSecret" text
);


ALTER TABLE public.users OWNER TO event_manager;

--
-- Name: webhook_configs; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.webhook_configs (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    events jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    secret text,
    headers jsonb,
    "retryAttempts" integer DEFAULT 3 NOT NULL,
    timeout integer DEFAULT 30 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.webhook_configs OWNER TO event_manager;

--
-- Name: webhook_deliveries; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.webhook_deliveries (
    id text NOT NULL,
    "webhookId" text NOT NULL,
    "eventId" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "attemptCount" integer DEFAULT 0 NOT NULL,
    "lastAttemptAt" timestamp(3) without time zone,
    "responseStatus" integer,
    "responseBody" text,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.webhook_deliveries OWNER TO event_manager;

--
-- Name: winner_signatures; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.winner_signatures (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "contestId" text NOT NULL,
    "eventId" text NOT NULL,
    "userId" text NOT NULL,
    "userRole" text NOT NULL,
    signature text NOT NULL,
    "signedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.winner_signatures OWNER TO event_manager;

--
-- Name: workflow_instances; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.workflow_instances (
    id text NOT NULL,
    "templateId" text NOT NULL,
    "tenantId" text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    "currentStepId" text,
    status text DEFAULT 'active'::text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    metadata jsonb
);


ALTER TABLE public.workflow_instances OWNER TO event_manager;

--
-- Name: workflow_step_executions; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.workflow_step_executions (
    id text NOT NULL,
    "instanceId" text NOT NULL,
    "stepId" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "completedBy" text,
    "approvalStatus" text,
    comments text,
    metadata jsonb,
    "tenantId" text NOT NULL
);


ALTER TABLE public.workflow_step_executions OWNER TO event_manager;

--
-- Name: workflow_steps; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.workflow_steps (
    id text NOT NULL,
    "templateId" text NOT NULL,
    name text NOT NULL,
    description text,
    "stepOrder" integer NOT NULL,
    "requiredRole" text,
    "autoAdvance" boolean DEFAULT false NOT NULL,
    "requireApproval" boolean DEFAULT true NOT NULL,
    conditions jsonb,
    actions jsonb,
    "notifyRoles" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.workflow_steps OWNER TO event_manager;

--
-- Name: workflow_templates; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.workflow_templates (
    id text NOT NULL,
    "tenantId" text,
    name text NOT NULL,
    description text,
    type text DEFAULT 'certification'::text NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    config jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.workflow_templates OWNER TO event_manager;

--
-- Name: workflow_transitions; Type: TABLE; Schema: public; Owner: event_manager
--

CREATE TABLE public.workflow_transitions (
    id text NOT NULL,
    "fromStepId" text NOT NULL,
    "toStepId" text NOT NULL,
    condition text DEFAULT 'approved'::text,
    "transitionType" text DEFAULT 'sequential'::text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.workflow_transitions OWNER TO event_manager;

--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.activity_logs (id, "userId", "userName", "userRole", action, "resourceType", "resourceId", "ipAddress", "userAgent", "logLevel", "createdAt", details, "tenantId") FROM stdin;
cmoolzirv0006yj5thssee2iz	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:21:43.628	"{\\"timestamp\\":\\"2026-05-02T17:21:43.626Z\\",\\"email\\":\\"admin@admintest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoolzppz0004m5kw4qoqq5vn	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:21:52.632	"{\\"timestamp\\":\\"2026-05-02T17:21:52.630Z\\",\\"email\\":\\"admin@advancedreportingtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom03gg000b3zp0avq9owcp	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:10.432	"{\\"timestamp\\":\\"2026-05-02T17:22:10.430Z\\",\\"email\\":\\"admin@assignmenttest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom03n7000g3zp06imvhg4g	\N	Test Admin	ADMIN	CREATE_ASSIGNMENT	ASSIGNMENT	\N	::ffff:127.0.0.1	Unknown	INFO	2026-05-02 17:22:10.676	"{\\"method\\":\\"POST\\",\\"path\\":\\"/\\",\\"timestamp\\":\\"2026-05-02T17:22:10.674Z\\",\\"body\\":{\\"categoryId\\":\\"cmoom038p00073zp0dk88grhc\\",\\"judgeId\\":\\"cmoom039100083zp039oejs6k\\"},\\"query\\":{},\\"params\\":{},\\"activityContext\\":null}"	cmoolzi8y0000yj5tgf7svd0x
cmoom03zb000p3zp0a5d8hrqz	\N	Test Admin	ADMIN	ASSIGN_CONTESTANT	ASSIGNMENT	\N	::ffff:127.0.0.1	Unknown	INFO	2026-05-02 17:22:11.111	"{\\"method\\":\\"POST\\",\\"path\\":\\"/contestants\\",\\"timestamp\\":\\"2026-05-02T17:22:11.110Z\\",\\"body\\":{\\"categoryId\\":\\"cmoom038p00073zp0dk88grhc\\",\\"contestantId\\":\\"cmoom039d00093zp0ik716jmt\\"},\\"query\\":{},\\"params\\":{},\\"activityContext\\":null}"	cmoolzi8y0000yj5tgf7svd0x
cmoom0r6z00094rbecvrbjmrf	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:41.196	"{\\"timestamp\\":\\"2026-05-02T17:22:41.194Z\\",\\"email\\":\\"admin@authtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom0sdc00154rbegzl0jmyx	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:42.72	"{\\"timestamp\\":\\"2026-05-02T17:22:42.719Z\\",\\"email\\":\\"admin@authtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom0r2200064rbeeebxffn8	\N	Test Contestant	CONTESTANT	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:41.018	"{\\"timestamp\\":\\"2026-05-02T17:22:41.016Z\\",\\"email\\":\\"contestant@authtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom0rqu000o4rbesfrve2dp	\N	Test Contestant	CONTESTANT	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:41.911	"{\\"timestamp\\":\\"2026-05-02T17:22:41.909Z\\",\\"email\\":\\"contestant@authtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom0rxp000s4rbekk42kcgz	\N	Test Contestant	CONTESTANT	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:42.158	"{\\"timestamp\\":\\"2026-05-02T17:22:42.157Z\\",\\"email\\":\\"contestant@authtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom0s1p000v4rbezq75x02j	\N	Test Contestant	CONTESTANT	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:42.302	"{\\"timestamp\\":\\"2026-05-02T17:22:42.301Z\\",\\"email\\":\\"contestant@authtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom0s5p000y4rbec6ipmser	\N	Test Contestant	CONTESTANT	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:42.445	"{\\"timestamp\\":\\"2026-05-02T17:22:42.444Z\\",\\"email\\":\\"contestant@authtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom0shl00184rbexyhe4yfb	\N	Test Contestant	CONTESTANT	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:42.873	"{\\"timestamp\\":\\"2026-05-02T17:22:42.872Z\\",\\"email\\":\\"contestant@authtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom0z7400046xge3zd5txjf	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:22:51.567	"{\\"timestamp\\":\\"2026-05-02T17:22:51.562Z\\",\\"email\\":\\"admin@backuptest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom161y0006147f6ubwaxhy	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:00.454	"{\\"timestamp\\":\\"2026-05-02T17:23:00.453Z\\",\\"email\\":\\"admin@biotest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom1cl80006j1bnfe0t6y3r	\N	Test Board	BOARD	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:08.924	"{\\"timestamp\\":\\"2026-05-02T17:23:08.923Z\\",\\"email\\":\\"board@boardtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom1cqc000aj1bnip57800y	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:09.109	"{\\"timestamp\\":\\"2026-05-02T17:23:09.108Z\\",\\"email\\":\\"admin@boardtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom1j7l0004enr17umrx7sa	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:17.505	"{\\"timestamp\\":\\"2026-05-02T17:23:17.504Z\\",\\"email\\":\\"admin@cachetest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom1pxt0007wf6nixc7srz0	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:26.225	"{\\"timestamp\\":\\"2026-05-02T17:23:26.224Z\\",\\"email\\":\\"admin@categorytest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom1q2n000bwf6npuw0gb9f	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:26.399	"{\\"timestamp\\":\\"2026-05-02T17:23:26.398Z\\",\\"email\\":\\"admin@categorytest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom1q79000ewf6nqtokgb07	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:26.565	"{\\"timestamp\\":\\"2026-05-02T17:23:26.564Z\\",\\"email\\":\\"admin@categorytest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom1qck000hwf6nh9whcorh	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:26.756	"{\\"timestamp\\":\\"2026-05-02T17:23:26.755Z\\",\\"email\\":\\"admin@categorytest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom1qh0000lwf6n11dpnzis	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:26.917	"{\\"timestamp\\":\\"2026-05-02T17:23:26.916Z\\",\\"email\\":\\"admin@categorytest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom1qlm000owf6nit9sv88v	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:27.082	"{\\"timestamp\\":\\"2026-05-02T17:23:27.081Z\\",\\"email\\":\\"admin@categorytest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom23ei0005y96c7wdfac5l	\N	test-user-1777742623282	ADMIN	CREATE_CATEGORY_TYPE	CATEGORY_TYPE	\N	::ffff:127.0.0.1	Unknown	INFO	2026-05-02 17:23:43.674	"{\\"method\\":\\"POST\\",\\"path\\":\\"/\\",\\"timestamp\\":\\"2026-05-02T17:23:43.672Z\\",\\"body\\":{\\"name\\":\\"cattype-test-test-1777742623626-c4d7xg\\",\\"description\\":\\"Test category type\\"},\\"query\\":{},\\"params\\":{},\\"activityContext\\":null}"	cmoolzi8y0000yj5tgf7svd0x
cmoom29v70006u3c2137wpu5d	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:52.052	"{\\"timestamp\\":\\"2026-05-02T17:23:52.050Z\\",\\"email\\":\\"admin@certificationtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom2a090009u3c2v7jekb9q	\N	Test Judge	JUDGE	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:23:52.233	"{\\"timestamp\\":\\"2026-05-02T17:23:52.232Z\\",\\"email\\":\\"judge@certificationtest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom2uap0005rc2ut7pr1fzq	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:24:18.529	"{\\"timestamp\\":\\"2026-05-02T17:24:18.528Z\\",\\"email\\":\\"admin@contesttest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom2ud4000arc2u8q3mwx93	\N	Test Admin	ADMIN	CREATE_CONTEST	CONTEST	cmoom2u380003rc2uzffrttyl	::ffff:127.0.0.1	Unknown	INFO	2026-05-02 17:24:18.616	"{\\"method\\":\\"POST\\",\\"path\\":\\"/event/cmoom2u380003rc2uzffrttyl\\",\\"timestamp\\":\\"2026-05-02T17:24:18.614Z\\",\\"body\\":{\\"name\\":\\"contest-test-1777742658566\\",\\"description\\":\\"Test contest description\\",\\"contestantNumberingMode\\":\\"MANUAL\\"},\\"query\\":{},\\"params\\":{\\"eventId\\":\\"cmoom2u380003rc2uzffrttyl\\"},\\"activityContext\\":null}"	cmoolzi8y0000yj5tgf7svd0x
cmoom2ulu000hrc2urfx75q64	\N	Test Admin	ADMIN	UPDATE_CONTEST	CONTEST	cmoom2ucv0008rc2ujg7jchfs	::ffff:127.0.0.1	Unknown	INFO	2026-05-02 17:24:18.93	"{\\"method\\":\\"PUT\\",\\"path\\":\\"/cmoom2ucv0008rc2ujg7jchfs\\",\\"timestamp\\":\\"2026-05-02T17:24:18.929Z\\",\\"body\\":{\\"description\\":\\"Updated description\\",\\"contestantNumberingMode\\":\\"AUTO_INDEXED\\"},\\"query\\":{},\\"params\\":{\\"id\\":\\"cmoom2ucv0008rc2ujg7jchfs\\"},\\"activityContext\\":null}"	cmoolzi8y0000yj5tgf7svd0x
cmoom2uoi000mrc2ucbzo2645	\N	Test Admin	ADMIN	DELETE_CONTEST	CONTEST	cmoom2und000krc2u6js4q5n6	::ffff:127.0.0.1	Unknown	INFO	2026-05-02 17:24:19.027	"{\\"method\\":\\"DELETE\\",\\"path\\":\\"/cmoom2und000krc2u6js4q5n6\\",\\"timestamp\\":\\"2026-05-02T17:24:19.025Z\\",\\"body\\":{},\\"query\\":{},\\"params\\":{\\"id\\":\\"cmoom2und000krc2u6js4q5n6\\"},\\"activityContext\\":null}"	cmoolzi8y0000yj5tgf7svd0x
cmoom2uqn000prc2usa9qk0ig	\N	Test Admin	ADMIN	ARCHIVE_CONTEST	CONTEST	cmoom2ucv0008rc2ujg7jchfs	::ffff:127.0.0.1	Unknown	INFO	2026-05-02 17:24:19.104	"{\\"method\\":\\"POST\\",\\"path\\":\\"/cmoom2ucv0008rc2ujg7jchfs/archive\\",\\"timestamp\\":\\"2026-05-02T17:24:19.102Z\\",\\"body\\":{},\\"query\\":{},\\"params\\":{\\"id\\":\\"cmoom2ucv0008rc2ujg7jchfs\\"},\\"activityContext\\":null}"	cmoolzi8y0000yj5tgf7svd0x
cmoom2us1000rrc2um85nzixd	\N	Test Admin	ADMIN	REACTIVATE_CONTEST	CONTEST	cmoom2ucv0008rc2ujg7jchfs	::ffff:127.0.0.1	Unknown	INFO	2026-05-02 17:24:19.154	"{\\"method\\":\\"POST\\",\\"path\\":\\"/cmoom2ucv0008rc2ujg7jchfs/reactivate\\",\\"timestamp\\":\\"2026-05-02T17:24:19.152Z\\",\\"body\\":{},\\"query\\":{},\\"params\\":{\\"id\\":\\"cmoom2ucv0008rc2ujg7jchfs\\"},\\"activityContext\\":null}"	cmoolzi8y0000yj5tgf7svd0x
cmoom37pe0004j51eqiwk2916	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:24:35.906	"{\\"timestamp\\":\\"2026-05-02T17:24:35.904Z\\",\\"email\\":\\"admin@dbbrowsertest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom3eg5000c7hdnk5e92f0u	\N	Test Judge	JUDGE	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:24:44.645	"{\\"timestamp\\":\\"2026-05-02T17:24:44.644Z\\",\\"email\\":\\"judge@deductiontest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
cmoom3eky000f7hdnfqk4ohkt	\N	Test Admin	ADMIN	LOGIN	AUTH	\N	::ffff:127.0.0.1	unknown	INFO	2026-05-02 17:24:44.818	"{\\"timestamp\\":\\"2026-05-02T17:24:44.817Z\\",\\"email\\":\\"admin@deductiontest.com\\"}"	cmoolzi8y0000yj5tgf7svd0x
\.


--
-- Data for Name: archived_events; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.archived_events (id, "eventId", name, description, "startDate", "endDate", "archivedAt", "archivedById", "tenantId") FROM stdin;
\.


--
-- Data for Name: assignments; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.assignments (id, "judgeId", "categoryId", "contestId", "eventId", status, "assignedAt", "assignedBy", notes, priority, "tenantId") FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.audit_logs (id, "userId", "userName", action, "entityType", "entityId", changes, "ipAddress", "userAgent", metadata, "timestamp", "tenantId") FROM stdin;
cmoolzis30007yj5tze2td7pu	cmoolzij30002yj5t99m3gnir	admin@admintest.com	auth.login	User	cmoolzij30002yj5t99m3gnir	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:21:43.636	cmoolzi8y0000yj5tgf7svd0x
cmoolzpq60005m5kwe0skrq6i	cmoolzpix0002m5kw3xtafj6v	admin@advancedreportingtest.com	auth.login	User	cmoolzpix0002m5kw3xtafj6v	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:21:52.639	cmoolzi8y0000yj5tgf7svd0x
cmoom03gm000c3zp0wug3b5tv	cmoom038900023zp08z8ykc14	admin@assignmenttest.com	auth.login	User	cmoom038900023zp08z8ykc14	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:22:10.438	cmoolzi8y0000yj5tgf7svd0x
cmoom0r2a00074rbe5yh28dyd	cmoom0qu600024rbe5hgc5hcg	contestant@authtest.com	auth.login	User	cmoom0qu600024rbe5hgc5hcg	\N	::ffff:127.0.0.1	\N	{"role": "CONTESTANT"}	2026-05-02 17:22:41.026	cmoolzi8y0000yj5tgf7svd0x
cmoom0r75000a4rbetajorodi	cmoom0quf00044rbes6wuv7be	admin@authtest.com	auth.login	User	cmoom0quf00044rbes6wuv7be	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:22:41.202	cmoolzi8y0000yj5tgf7svd0x
cmoom0rc8000c4rbe8t28ykif	\N	contestant@authtest.com	auth.failed_login	User	\N	\N	::ffff:127.0.0.1	\N	{"reason": "Invalid credentials"}	2026-05-02 17:22:41.385	cmoolzi8y0000yj5tgf7svd0x
cmoom0rd7000e4rbe4l54q2c0	\N	nonexistent@authtest.com	auth.failed_login	User	\N	\N	::ffff:127.0.0.1	\N	{"reason": "Invalid credentials"}	2026-05-02 17:22:41.42	cmoolzi8y0000yj5tgf7svd0x
cmoom0rmp000l4rbexsxge60t	\N	inactive@authtest.com	auth.failed_login	User	\N	\N	::ffff:127.0.0.1	\N	{"reason": "Account is inactive"}	2026-05-02 17:22:41.761	cmoolzi8y0000yj5tgf7svd0x
cmoom0rqx000p4rbebrbzgthi	cmoom0qu600024rbe5hgc5hcg	contestant@authtest.com	auth.login	User	cmoom0qu600024rbe5hgc5hcg	\N	::ffff:127.0.0.1	\N	{"role": "CONTESTANT"}	2026-05-02 17:22:41.914	cmoolzi8y0000yj5tgf7svd0x
cmoom0rxs000t4rbefimm3x9h	cmoom0qu600024rbe5hgc5hcg	contestant@authtest.com	auth.login	User	cmoom0qu600024rbe5hgc5hcg	\N	::ffff:127.0.0.1	\N	{"role": "CONTESTANT"}	2026-05-02 17:22:42.161	cmoolzi8y0000yj5tgf7svd0x
cmoom0s1s000w4rbe4rea84a6	cmoom0qu600024rbe5hgc5hcg	contestant@authtest.com	auth.login	User	cmoom0qu600024rbe5hgc5hcg	\N	::ffff:127.0.0.1	\N	{"role": "CONTESTANT"}	2026-05-02 17:22:42.305	cmoolzi8y0000yj5tgf7svd0x
cmoom0s5t000z4rbeck2uxadr	cmoom0qu600024rbe5hgc5hcg	contestant@authtest.com	auth.login	User	cmoom0qu600024rbe5hgc5hcg	\N	::ffff:127.0.0.1	\N	{"role": "CONTESTANT"}	2026-05-02 17:22:42.449	cmoolzi8y0000yj5tgf7svd0x
cmoom0s7800104rbec4b5eo2e	\N	contestant@authtest.com	auth.password_reset	User	\N	\N	::ffff:127.0.0.1	\N	{"action_type": "request"}	2026-05-02 17:22:42.501	cmoolzi8y0000yj5tgf7svd0x
cmoom0sde00164rbejzj6vq34	cmoom0quf00044rbes6wuv7be	admin@authtest.com	auth.login	User	cmoom0quf00044rbes6wuv7be	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:22:42.723	cmoolzi8y0000yj5tgf7svd0x
cmoom0shp00194rbeako45efj	cmoom0qu600024rbe5hgc5hcg	contestant@authtest.com	auth.login	User	cmoom0qu600024rbe5hgc5hcg	\N	::ffff:127.0.0.1	\N	{"role": "CONTESTANT"}	2026-05-02 17:22:42.877	cmoolzi8y0000yj5tgf7svd0x
cmoom0z7f00056xgewlyyopet	cmoom0yuv00026xge6gq4laft	admin@backuptest.com	auth.login	User	cmoom0yuv00026xge6gq4laft	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:22:51.579	cmoolzi8y0000yj5tgf7svd0x
cmoom16250007147fv79gnqqv	cmoom15uf0002147fyv6idm9s	admin@biotest.com	auth.login	User	cmoom15uf0002147fyv6idm9s	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:00.461	cmoolzi8y0000yj5tgf7svd0x
cmoom1clg0007j1bn70e9v2r0	cmoom1cdf0002j1bnhn9li7qb	board@boardtest.com	auth.login	User	cmoom1cdf0002j1bnhn9li7qb	\N	::ffff:127.0.0.1	\N	{"role": "BOARD"}	2026-05-02 17:23:08.932	cmoolzi8y0000yj5tgf7svd0x
cmoom1cqi000bj1bnztiqpsx6	cmoom1cdo0004j1bn8cy2i03q	admin@boardtest.com	auth.login	User	cmoom1cdo0004j1bn8cy2i03q	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:09.115	cmoolzi8y0000yj5tgf7svd0x
cmoom1j7s0005enr1nrebko9o	cmoom1j0n0002enr1k3x4fj7s	admin@cachetest.com	auth.login	User	cmoom1j0n0002enr1k3x4fj7s	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:17.513	cmoolzi8y0000yj5tgf7svd0x
cmoom1pxz0008wf6n9b3so7gz	cmoom1pq00002wf6n4fsbbcso	admin@categorytest.com	auth.login	User	cmoom1pq00002wf6n4fsbbcso	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:26.231	cmoolzi8y0000yj5tgf7svd0x
cmoom1q2r000cwf6n1ocqpg1u	cmoom1pq00002wf6n4fsbbcso	admin@categorytest.com	auth.login	User	cmoom1pq00002wf6n4fsbbcso	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:26.403	cmoolzi8y0000yj5tgf7svd0x
cmoom1q7e000fwf6nm6aeivgd	cmoom1pq00002wf6n4fsbbcso	admin@categorytest.com	auth.login	User	cmoom1pq00002wf6n4fsbbcso	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:26.571	cmoolzi8y0000yj5tgf7svd0x
cmoom1qcn000iwf6nn9p7bxgw	cmoom1pq00002wf6n4fsbbcso	admin@categorytest.com	auth.login	User	cmoom1pq00002wf6n4fsbbcso	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:26.759	cmoolzi8y0000yj5tgf7svd0x
cmoom1qh3000mwf6nh1397d6r	cmoom1pq00002wf6n4fsbbcso	admin@categorytest.com	auth.login	User	cmoom1pq00002wf6n4fsbbcso	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:26.92	cmoolzi8y0000yj5tgf7svd0x
cmoom1qlp000pwf6n7q0m2uzg	cmoom1pq00002wf6n4fsbbcso	admin@categorytest.com	auth.login	User	cmoom1pq00002wf6n4fsbbcso	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:27.085	cmoolzi8y0000yj5tgf7svd0x
cmoom29vf0007u3c2wr6bcbd8	cmoom29o40002u3c2f6anfpdb	admin@certificationtest.com	auth.login	User	cmoom29o40002u3c2f6anfpdb	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:23:52.059	cmoolzi8y0000yj5tgf7svd0x
cmoom2a0d000au3c26gp9k4jr	cmoom29of0004u3c2va437no7	judge@certificationtest.com	auth.login	User	cmoom29of0004u3c2va437no7	\N	::ffff:127.0.0.1	\N	{"role": "JUDGE"}	2026-05-02 17:23:52.238	cmoolzi8y0000yj5tgf7svd0x
cmoom2uav0006rc2u1msz4so9	cmoom2u310002rc2uyko3xgn5	admin@contesttest.com	auth.login	User	cmoom2u310002rc2uyko3xgn5	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:24:18.536	cmoolzi8y0000yj5tgf7svd0x
cmoom37po0005j51eryqtm81l	cmoom37ho0002j51esur2xwh6	admin@dbbrowsertest.com	auth.login	User	cmoom37ho0002j51esur2xwh6	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:24:35.916	cmoolzi8y0000yj5tgf7svd0x
cmoom3egb000d7hdnbmr8w0td	cmoom3e8100027hdno4i0fnbr	judge@deductiontest.com	auth.login	User	cmoom3e8100027hdno4i0fnbr	\N	::ffff:127.0.0.1	\N	{"role": "JUDGE"}	2026-05-02 17:24:44.652	cmoolzi8y0000yj5tgf7svd0x
cmoom3el2000g7hdn2bxb3yaa	cmoom3e8900047hdncp81oc40	admin@deductiontest.com	auth.login	User	cmoom3e8900047hdncp81oc40	\N	::ffff:127.0.0.1	\N	{"role": "ADMIN"}	2026-05-02 17:24:44.823	cmoolzi8y0000yj5tgf7svd0x
\.


--
-- Data for Name: auditor_assignments; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.auditor_assignments (id, "userId", "categoryId", "contestId", "eventId", status, "assignedAt", "assignedBy", notes, "tenantId") FROM stdin;
\.


--
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.backup_logs (id, location, size, "createdAt", "errorMessage", type, status, "tenantId", "startedAt", "completedAt", duration, metadata) FROM stdin;
cmoom3lnl0008tw32sywil8nm	/srv/event-manager/dev/backups/backup-full-2026-05-02T17-24-53-557Z.sql.gz	26802	2026-05-02 17:24:53.985	\N	full	success	cmoolzi8y0000yj5tgf7svd0x	2026-05-02 17:24:53.548	2026-05-02 17:24:53.983	0	{"encryption": false, "scheduleId": "cmoom3l7i0005tw322g43yqir", "compression": true, "scheduleName": "Daily Full Backup"}
\.


--
-- Data for Name: backup_schedules; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.backup_schedules (id, "tenantId", name, "backupType", frequency, enabled, "retentionDays", "nextRunAt", "lastRunAt", "lastStatus", targets, compression, encryption, "createdAt", "updatedAt") FROM stdin;
cmoom3l7i0005tw322g43yqir	cmoolzi8y0000yj5tgf7svd0x	Daily Full Backup	full	daily	f	14	2026-05-03 17:24:53.99	2026-05-02 17:24:54.252	success	[]	t	f	2026-05-02 17:24:53.406	2026-05-02 17:24:54.255
\.


--
-- Data for Name: backup_settings; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.backup_settings (id, "retentionDays", "createdAt", "updatedAt", "backupType", enabled, frequency, "frequencyValue") FROM stdin;
\.


--
-- Data for Name: backup_targets; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.backup_targets (id, "tenantId", name, type, config, enabled, priority, verified, "lastVerified", "createdAt", "updatedAt") FROM stdin;
cmoom3lq1000dtw32ssrb0oam	cmoolzi8y0000yj5tgf7svd0x	AWS S3 Backup	S3	{"bucket": "event-manager-backups", "region": "us-east-1", "accessKeyId": "test-key", "secretAccessKey": "test-secret"}	t	0	f	\N	2026-05-02 17:24:54.074	2026-05-02 17:24:54.074
cmoom3lpc000ctw32az5neecm	cmoolzi8y0000yj5tgf7svd0x	Local Storage	LOCAL	{"path": "/var/backups/event-manager"}	f	0	f	2026-05-02 17:24:54.1	2026-05-02 17:24:54.048	2026-05-02 17:24:54.225
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.categories (id, "contestId", name, description, "scoreCap", "timeLimit", "contestantMin", "contestantMax", "createdAt", "updatedAt", "totalsCertified", "tenantId", "boardApproved", "approvedAt", "approvedBy", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: category_certifications; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.category_certifications (id, "categoryId", role, "userId", "signatureName", "boardRoleSnapshot", "certifiedAt", comments, "tenantId") FROM stdin;
\.


--
-- Data for Name: category_contestants; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.category_contestants ("categoryId", "contestantId", "tenantId") FROM stdin;
\.


--
-- Data for Name: category_judges; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.category_judges ("categoryId", "judgeId", "tenantId") FROM stdin;
\.


--
-- Data for Name: category_templates; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.category_templates (id, name, description, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: category_types; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.category_types (id, name, description, "isSystem", "createdById", "createdAt") FROM stdin;
cmoom23ea0003y96cy0zzmqiz	cattype-test-test-1777742623626-c4d7xg	Test category type	f	cmoom236k0002y96c3nkj592l	2026-05-02 17:23:43.666
\.


--
-- Data for Name: certifications; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.certifications (id, "categoryId", "contestId", "eventId", "userId", status, "currentStep", "totalSteps", "judgeCertified", "tallyCertified", "auditorCertified", "boardApproved", "certifiedAt", "certifiedBy", "rejectionReason", comments, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: contest_certifications; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.contest_certifications (id, "contestId", role, "userId", "boardRoleSnapshot", "certifiedAt", comments, "tenantId") FROM stdin;
\.


--
-- Data for Name: contest_contestants; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.contest_contestants ("contestId", "contestantId", "tenantId") FROM stdin;
\.


--
-- Data for Name: contest_judges; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.contest_judges ("contestId", "judgeId", "tenantId") FROM stdin;
\.


--
-- Data for Name: contestants; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.contestants (id, name, email, gender, pronouns, "contestantNumber", bio, "imagePath", "createdAt", "updatedAt", "tenantId") FROM stdin;
cmoom039d00093zp0ik716jmt	Test Contestant	contestant@assignmenttest.com	\N	\N	1	\N	\N	2026-05-02 17:22:10.177	2026-05-02 17:22:10.177	cmoolzi8y0000yj5tgf7svd0x
cmoom15v00004147fefkqq5xs	Test Contestant	contestant@biotest.com	\N	\N	1	Test contestant bio	\N	2026-05-02 17:23:00.205	2026-05-02 17:23:00.205	cmoolzi8y0000yj5tgf7svd0x
cmoom3e8s000a7hdn1z1jy1cr	Test Contestant	contestant@deductiontest.com	\N	\N	1	\N	\N	2026-05-02 17:24:44.381	2026-05-02 17:24:44.381	cmoolzi8y0000yj5tgf7svd0x
\.


--
-- Data for Name: contests; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.contests (id, "eventId", name, description, "createdAt", "updatedAt", "contestantNumberingMode", "nextContestantNumber", archived, "contestantViewRestricted", "contestantViewReleaseDate", "isLocked", "lockedAt", "lockVerifiedBy", "scoringType", "tenantId", "winnersPublished", "publishedAt", "publishedBy", "deletedAt", "deletedBy") FROM stdin;
cmoom038l00053zp0diuv7tm5	cmoom038g00033zp0gqf4skg2	contest-test-1777742530147	Test contest	2026-05-02 17:22:10.149	2026-05-02 17:24:45.019	MANUAL	1	f	f	\N	f	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	f	\N	\N	2026-05-02 17:24:45.017	\N
cmoom1pqa0005wf6nczdptep0	cmoom1pq70003wf6n9c08xvk8	contest-test-1777742605953	Test contest for categories	2026-05-02 17:23:25.954	2026-05-02 17:24:45.019	MANUAL	1	f	f	\N	f	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	f	\N	\N	2026-05-02 17:24:45.017	\N
cmoom2und000krc2u6js4q5n6	cmoom2u380003rc2uzffrttyl	contest-test-delete-1777742658984	Test contest to delete	2026-05-02 17:24:18.986	2026-05-02 17:24:45.019	MANUAL	1	f	f	\N	f	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	f	\N	\N	2026-05-02 17:24:45.017	cmoom2u310002rc2uyko3xgn5
cmoom2ucv0008rc2ujg7jchfs	cmoom2u380003rc2uzffrttyl	contest-test-1777742658566	Updated description	2026-05-02 17:24:18.607	2026-05-02 17:24:45.019	AUTO_INDEXED	1	f	f	\N	f	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	f	\N	\N	2026-05-02 17:24:45.017	\N
cmoom3e8g00077hdn7ufyxge3	cmoom3e8d00057hdnynwsawyj	contest-test-1777742684367	Test contest	2026-05-02 17:24:44.368	2026-05-02 17:24:45.019	MANUAL	1	f	f	\N	f	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	f	\N	\N	2026-05-02 17:24:45.017	\N
\.


--
-- Data for Name: criteria; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.criteria (id, "categoryId", name, "maxScore", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: custom_field_values; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.custom_field_values (id, "customFieldId", "entityId", value, "createdAt", "updatedAt", "tenantId") FROM stdin;
cmoom319t000pjki591d7axdk	cmoom318n000mjki5svze62lp	cmoom30q40004jki54gd7ugt2	https://example.com	2026-05-02 17:24:27.569	2026-05-02 17:24:27.569	cmoolzi8y0000yj5tgf7svd0x
cmoom315c000ijki5p4476ayu	cmoom30t20005jki5ibaj618u	cmoom30q40004jki54gd7ugt2	(555) 987-6543	2026-05-02 17:24:27.408	2026-05-02 17:24:27.617	cmoolzi8y0000yj5tgf7svd0x
cmoom3166000kjki5e56mqpnp	cmoom30up0006jki53g1leuah	cmoom30q40004jki54gd7ugt2	XL	2026-05-02 17:24:27.438	2026-05-02 17:24:27.621	cmoolzi8y0000yj5tgf7svd0x
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.custom_fields (id, name, key, type, "entityType", required, "defaultValue", options, validation, "order", active, "createdAt", "updatedAt", "tenantId") FROM stdin;
cmoom30vi0007jki5dnelzuxa	Interests	interests	MULTI_SELECT	USER	f	\N	"[\\"Music\\",\\"Dance\\",\\"Acting\\",\\"Singing\\"]"	\N	2	t	2026-05-02 17:24:27.055	2026-05-02 17:24:27.055	cmoolzi8y0000yj5tgf7svd0x
cmoom30w90008jki5of3iltce	Age	age	NUMBER	CONTESTANT	t	\N	\N	"{\\"min\\":5,\\"max\\":25}"	0	t	2026-05-02 17:24:27.082	2026-05-02 17:24:27.082	cmoolzi8y0000yj5tgf7svd0x
cmoom30x10009jki50bs4he7v	Registration Deadline	registrationDeadline	DATE	EVENT	t	\N	\N	\N	0	t	2026-05-02 17:24:27.11	2026-05-02 17:24:27.11	cmoolzi8y0000yj5tgf7svd0x
cmoom30xs000bjki5duotpgun	Needs Special Accommodation	needsAccommodation	BOOLEAN	CONTESTANT	f	\N	\N	\N	1	t	2026-05-02 17:24:27.137	2026-05-02 17:24:27.137	cmoolzi8y0000yj5tgf7svd0x
cmoom30yh000cjki5yb9u7r93	Alternate Email	alternateEmail	EMAIL	JUDGE	f	\N	\N	\N	0	t	2026-05-02 17:24:27.161	2026-05-02 17:24:27.161	cmoolzi8y0000yj5tgf7svd0x
cmoom30z5000djki59b0tti0v	Portfolio Website	portfolioUrl	URL	CONTESTANT	f	\N	\N	\N	2	t	2026-05-02 17:24:27.186	2026-05-02 17:24:27.186	cmoolzi8y0000yj5tgf7svd0x
cmoom30t20005jki5ibaj618u	Phone Number	phoneNumber	PHONE	USER	t	\N	\N	\N	5	t	2026-05-02 17:24:26.966	2026-05-02 17:24:27.299	cmoolzi8y0000yj5tgf7svd0x
cmoom30up0006jki53g1leuah	T-Shirt Size	tshirtSize	SELECT	USER	t	\N	"[\\"XS\\",\\"S\\",\\"M\\",\\"L\\",\\"XL\\",\\"XXL\\"]"	\N	1	t	2026-05-02 17:24:27.026	2026-05-02 17:24:27.326	cmoolzi8y0000yj5tgf7svd0x
cmoom317f000ljki5uf26b12j	Contact Email	contactEmail	EMAIL	USER	f	\N	\N	\N	10	t	2026-05-02 17:24:27.484	2026-05-02 17:24:27.484	cmoolzi8y0000yj5tgf7svd0x
cmoom318n000mjki5svze62lp	Website	website	URL	USER	f	\N	\N	\N	11	t	2026-05-02 17:24:27.527	2026-05-02 17:24:27.527	cmoolzi8y0000yj5tgf7svd0x
\.


--
-- Data for Name: deduction_approvals; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.deduction_approvals (id, "requestId", "approvedById", role, "boardRoleSnapshot", "isHeadJudge", "approvedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: deduction_requests; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.deduction_requests (id, "contestantId", "categoryId", amount, reason, "requestedById", status, "createdAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: dr_configs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.dr_configs (id, "tenantId", "backupFrequency", "backupRetentionDays", "enableAutoBackup", "enablePITR", "enableDRTesting", "drTestFrequency", "backupLocations", "rtoMinutes", "rpoMinutes", "alertEmail", "enableFailover", "healthCheckInterval", "createdAt", "updatedAt") FROM stdin;
cmoom3l3d0003tw32ggmhi4ay	cmoolzi8y0000yj5tgf7svd0x	daily	30	t	f	t	weekly	[]	120	30	admin@example.com	t	5	2026-05-02 17:24:53.257	2026-05-02 17:24:53.347
\.


--
-- Data for Name: dr_metrics; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.dr_metrics (id, "tenantId", "metricType", value, unit, "timestamp", metadata) FROM stdin;
cmoom3lnw0009tw32hlzirv66	cmoolzi8y0000yj5tgf7svd0x	backup_duration	0	seconds	2026-05-02 17:24:53.997	{"backupType": "full", "scheduleId": "cmoom3l7i0005tw322g43yqir"}
cmoom3lo0000atw320zcecngd	cmoolzi8y0000yj5tgf7svd0x	backup_size	26802	bytes	2026-05-02 17:24:54.001	{"backupType": "full", "scheduleId": "cmoom3l7i0005tw322g43yqir"}
\.


--
-- Data for Name: dr_test_logs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.dr_test_logs (id, "tenantId", "testType", "backupId", status, "startedAt", "completedAt", duration, "testResults", "errorMessage", "automatedTest", "testedBy", notes, "createdAt") FROM stdin;
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.email_logs (id, "to", "from", subject, template, status, "messageId", "errorMessage", "sentAt", "createdAt", "updatedAt", "tenantId", "userId", metadata) FROM stdin;
cmoom0s7f00114rbeau5xlq1f	contestant@authtest.com	noreply@example.com	Reset Your Password	password-reset	SKIPPED	\N	SMTP disabled	2026-05-02 17:22:42.506	2026-05-02 17:22:42.507	2026-05-02 17:22:42.507	cmoolzi8y0000yj5tgf7svd0x	\N	{"name": "Test Contestant", "appName": "Event Manager", "resetUrl": "http://localhost:3001/reset-password?token=ec401a1dedbd91e18d8b40d053dac9b502522f5e4596768bf62500c4445ab690", "supportEmail": "noreply@example.com"}
\.


--
-- Data for Name: email_settings; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.email_settings (id, "smtpHost", "smtpPort", "smtpSecure", "smtpUser", "smtpPassword", "fromEmail", "fromName", "enableEmail", "enableNotifications", "enableReports", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.email_templates (id, name, subject, body, type, "eventId", variables, "createdBy", "createdAt", "updatedAt", "headerHtml", "footerHtml", "logoUrl", "logoPosition", "backgroundColor", "primaryColor", "textColor", "fontFamily", "fontSize", "layoutType", "contentWrapper", "borderStyle", "borderColor", "borderWidth", "borderRadius", padding, margin, "templateData", "tenantId") FROM stdin;
\.


--
-- Data for Name: emcee_scripts; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.emcee_scripts (id, "eventId", "contestId", "categoryId", title, content, "order", "createdAt", "updatedAt", file_path, "tenantId") FROM stdin;
\.


--
-- Data for Name: error_logs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.error_logs (id, message, stack, level, context, "userId", path, method, "statusCode", metadata, resolved, "resolvedAt", "resolvedBy", "createdAt", "tenantId") FROM stdin;
cmoolzwj100041p2ehtwejd8r	Event with identifier 'test-event-id' not found	NotFoundError: Event with identifier 'test-event-id' not found\n    at ArchiveService.notFoundError (/srv/event-manager/dev/src/services/BaseService.ts:146:12)\n    at ArchiveService.archiveEvent (/srv/event-manager/dev/src/services/ArchiveService.ts:173:18)\n    at archiveEvent (/srv/event-manager/dev/src/controllers/archiveController.ts:143:23)	ERROR	\N	cmoolzwcp00021p2eko3aaqoh	/api/archive/event/test-event-id	POST	404	{"query": {}, "params": {}, "errorCode": "RESOURCE_NOT_FOUND", "ipAddress": "::ffff:127.0.0.1", "requestId": "52a8e3e9-e7d0-4eae-ad5a-e855a45b92f0", "userAgent": "Unknown"}	f	\N	\N	2026-05-02 17:22:01.454	cmoolzi8y0000yj5tgf7svd0x
cmoom0rc3000b4rbexu5nfv08	Invalid credentials	Error: Invalid credentials\n    at AuthService.login (/srv/event-manager/dev/src/services/AuthService.ts:455:11)\n    at login (/srv/event-manager/dev/src/controllers/authController.ts:56:22)	ERROR	AuthService:login	\N	\N	\N	\N	{"email": "contestant@authtest.com", "reason": "invalid_credentials", "tenantId": "cmoolzi8y0000yj5tgf7svd0x", "ipAddress": "::ffff:127.0.0.1", "userAgent": "unknown"}	f	\N	\N	2026-05-02 17:22:41.379	cmoolzi8y0000yj5tgf7svd0x
cmoom0rd4000d4rberrt9rvng	Invalid credentials	Error: Invalid credentials\n    at AuthService.login (/srv/event-manager/dev/src/services/AuthService.ts:455:11)\n    at login (/srv/event-manager/dev/src/controllers/authController.ts:56:22)	ERROR	AuthService:login	\N	\N	\N	\N	{"email": "nonexistent@authtest.com", "reason": "invalid_credentials", "tenantId": "cmoolzi8y0000yj5tgf7svd0x", "ipAddress": "::ffff:127.0.0.1", "userAgent": "unknown"}	f	\N	\N	2026-05-02 17:22:41.417	cmoolzi8y0000yj5tgf7svd0x
cmoom0rml000k4rbe7t59z83d	Account is inactive	Error: Account is inactive\n    at AuthService.login (/srv/event-manager/dev/src/services/AuthService.ts:478:11)\n    at login (/srv/event-manager/dev/src/controllers/authController.ts:56:22)	ERROR	AuthService:login	\N	\N	\N	\N	{"email": "inactive@authtest.com", "reason": "inactive_account", "userId": "cmoom0rji000j4rbezwxzvow3", "tenantId": "cmoolzi8y0000yj5tgf7svd0x", "ipAddress": "::ffff:127.0.0.1", "userAgent": "unknown"}	f	\N	\N	2026-05-02 17:22:41.758	cmoolzi8y0000yj5tgf7svd0x
cmoom2uk9000erc2umgbz0dab	Contest with identifier 'clx00000000000000000000000' not found	NotFoundError: Contest with identifier 'clx00000000000000000000000' not found\n    at ContestService.notFoundError (/srv/event-manager/dev/src/services/BaseService.ts:146:12)\n    at ContestService.getContestWithDetails (/srv/event-manager/dev/src/services/ContestService.ts:210:20)\n    at getContestById (/srv/event-manager/dev/src/controllers/contestsController.ts:177:23)	ERROR	\N	cmoom2u310002rc2uyko3xgn5	/api/contests/clx00000000000000000000000	GET	404	{"query": {}, "params": {}, "errorCode": "RESOURCE_NOT_FOUND", "ipAddress": "::ffff:127.0.0.1", "requestId": "408fd7f3-daea-439a-a28d-7c493079522a", "userAgent": "Unknown"}	f	\N	\N	2026-05-02 17:24:18.873	cmoolzi8y0000yj5tgf7svd0x
cmoom2una000irc2ulfjys0ue	Contest with identifier 'clx00000000000000000000000' not found	NotFoundError: Contest with identifier 'clx00000000000000000000000' not found\n    at ContestService.notFoundError (/srv/event-manager/dev/src/services/BaseService.ts:146:12)\n    at ContestService.getContestById (/srv/event-manager/dev/src/services/ContestService.ts:183:20)\n    at ContestService.updateContest (/srv/event-manager/dev/src/services/ContestService.ts:331:24)\n    at updateContest (/srv/event-manager/dev/src/controllers/contestsController.ts:257:23)	ERROR	\N	cmoom2u310002rc2uyko3xgn5	/api/contests/clx00000000000000000000000	PUT	404	{"query": {}, "params": {}, "errorCode": "RESOURCE_NOT_FOUND", "ipAddress": "::ffff:127.0.0.1", "requestId": "45bd32e6-5487-4798-bdd9-62d6c0637b1d", "userAgent": "Unknown"}	f	\N	\N	2026-05-02 17:24:18.982	cmoolzi8y0000yj5tgf7svd0x
cmoom2upf000nrc2u1t72lbpq	Contest with identifier 'clx00000000000000000000000' not found	NotFoundError: Contest with identifier 'clx00000000000000000000000' not found\n    at ContestService.notFoundError (/srv/event-manager/dev/src/services/BaseService.ts:146:12)\n    at ContestService.getContestById (/srv/event-manager/dev/src/services/ContestService.ts:183:20)\n    at ContestService.deleteContest (/srv/event-manager/dev/src/services/ContestService.ts:394:23)\n    at deleteContest (/srv/event-manager/dev/src/controllers/contestsController.ts:311:7)	ERROR	\N	cmoom2u310002rc2uyko3xgn5	/api/contests/clx00000000000000000000000	DELETE	404	{"query": {}, "params": {}, "errorCode": "RESOURCE_NOT_FOUND", "ipAddress": "::ffff:127.0.0.1", "requestId": "02a4af9a-1e72-4ff8-80c5-9aa3e65c2de5", "userAgent": "Unknown"}	f	\N	\N	2026-05-02 17:24:19.059	cmoolzi8y0000yj5tgf7svd0x
cmoom3lsw000ftw32rtwijijn	Backup target nonexistent-target not found	Error: Backup target nonexistent-target not found\n    at Function.verifyBackupTarget (/srv/event-manager/dev/src/services/DRAutomationService.ts:450:15)\n    at verifyBackupTarget (/srv/event-manager/dev/src/controllers/drController.ts:371:22)	ERROR	\N	cmoom3l070002tw322ibj8alh	/api/dr/targets/nonexistent-target/verify	POST	500	{"query": {}, "params": {}, "ipAddress": "::ffff:127.0.0.1", "requestId": "e40385c4-016e-4f63-96c5-e153e7dcfc17", "userAgent": "Unknown"}	f	\N	\N	2026-05-02 17:24:54.177	cmoolzi8y0000yj5tgf7svd0x
\.


--
-- Data for Name: event_logs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.event_logs (id, "tenantId", "eventType", "entityType", "entityId", payload, "userId", source, "correlationId", "timestamp", processed, "processedAt", "retryCount", "lastError", metadata) FROM stdin;
\.


--
-- Data for Name: event_templates; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.event_templates (id, name, description, contests, categories, "createdBy", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.events (id, name, description, "startDate", "endDate", "createdAt", "updatedAt", archived, location, "maxContestants", "contestantNumberingMode", "contestantViewRestricted", "isLocked", "contestantViewReleaseDate", "lockedAt", "lockVerifiedBy", "scoringType", "requireAllTallyCertifiers", "requireAllAuditorCertifiers", "tenantId", "deletedAt", "deletedBy") FROM stdin;
cmoom038g00033zp0gqf4skg2	event-test-1777742530144	Test event	2024-07-01 00:00:00	2024-07-03 00:00:00	2026-05-02 17:22:10.145	2026-05-02 17:24:45.022	f	Test Location	\N	MANUAL	f	f	\N	\N	\N	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	2026-05-02 17:24:45.021	\N
cmoom1pq70003wf6n9c08xvk8	event-test-1777742605950	Test event for categories	2024-07-01 00:00:00	2024-07-03 00:00:00	2026-05-02 17:23:25.951	2026-05-02 17:24:45.022	f	Test Location	\N	MANUAL	f	f	\N	\N	\N	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	2026-05-02 17:24:45.021	\N
cmoom2u380003rc2uzffrttyl	event-test-1777742658259	Test event for contests	2024-07-01 00:00:00	2024-07-03 00:00:00	2026-05-02 17:24:18.261	2026-05-02 17:24:45.022	f	Test Location	\N	MANUAL	f	f	\N	\N	\N	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	2026-05-02 17:24:45.021	\N
cmoom3e8d00057hdnynwsawyj	event-test-1777742684363	Test event	2024-07-01 00:00:00	2024-07-03 00:00:00	2026-05-02 17:24:44.365	2026-05-02 17:24:45.022	f	Test Location	\N	MANUAL	f	f	\N	\N	\N	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	2026-05-02 17:24:45.021	\N
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.feature_flags (id, name, description, enabled, strategy, percentage, "userIds", "tenantIds", "startDate", "endDate", "targetPercentage", "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.files (id, filename, "originalName", "mimeType", size, path, category, "uploadedBy", "uploadedAt", "isPublic", metadata, checksum, "eventId", "contestId", "categoryId", "tenantId") FROM stdin;
\.


--
-- Data for Name: idempotency_records; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.idempotency_records (id, "tenantId", "actorType", "actorId", method, path, "canonicalPath", key, "requestHash", status, "statusCode", "errorCode", "responseBody", digest, "expiresAt", "leaseExpiresAt", "createdAt", "updatedAt", "lastSeenAt") FROM stdin;
\.


--
-- Data for Name: judge_certifications; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.judge_certifications (id, "categoryId", "judgeId", "signatureName", "certifiedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: judge_comments; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.judge_comments (id, "categoryId", "contestantId", "judgeId", comment, "createdAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: judge_contestant_certifications; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.judge_contestant_certifications (id, "categoryId", "judgeId", "contestantId", "certifiedAt", comments, "tenantId") FROM stdin;
\.


--
-- Data for Name: judge_score_removal_requests; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.judge_score_removal_requests (id, "categoryId", "contestantId", "judgeId", "scoreId", reason, status, "requestedAt", "reviewedAt", "reviewedById", "tenantId") FROM stdin;
\.


--
-- Data for Name: judge_uncertification_requests; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.judge_uncertification_requests (id, "categoryId", "judgeId", reason, "requestedBy", "requestedByBoardRoleSnapshot", "requestedAt", "approvedBy", "approvedByBoardRoleSnapshot", "approvedAt", "rejectedBy", "rejectedByBoardRoleSnapshot", "rejectedAt", "rejectionReason", "createdAt", "updatedAt", status, "tenantId") FROM stdin;
\.


--
-- Data for Name: judges; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.judges (id, name, email, gender, pronouns, bio, "imagePath", "createdAt", "updatedAt", "isHeadJudge", "tenantId") FROM stdin;
cmoom039100083zp039oejs6k	Test Judge	judge@assignmenttest.com	\N	\N	\N	\N	2026-05-02 17:22:10.165	2026-05-02 17:22:10.165	f	cmoolzi8y0000yj5tgf7svd0x
cmoom15ut0003147fylyowobm	Test Judge	judge@biotest.com	\N	\N	Test judge bio	\N	2026-05-02 17:23:00.198	2026-05-02 17:23:00.198	f	cmoolzi8y0000yj5tgf7svd0x
\.


--
-- Data for Name: logging_settings; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.logging_settings (id, level, "enableAudit", "enableActivity", "enableError", "maxLogAge", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: notification_digests; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.notification_digests (id, "userId", frequency, "lastSentAt", "nextSendAt", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.notification_preferences (id, "userId", "emailEnabled", "pushEnabled", "inAppEnabled", "emailDigestFrequency", "emailTypes", "pushTypes", "inAppTypes", "quietHoursStart", "quietHoursEnd", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.notification_templates (id, name, type, title, body, "emailSubject", "emailBody", variables, "isActive", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.notifications (id, "userId", type, title, message, link, read, "readAt", metadata, "createdAt", "updatedAt", "tenantId", "emailSent", "emailSentAt", "pushSent", "pushSentAt", "templateId", "sentBy", "deletedAt") FROM stdin;
\.


--
-- Data for Name: overall_deductions; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.overall_deductions (id, "categoryId", "contestantId", deduction, reason, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: password_histories; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.password_histories (id, "userId", password, "createdAt") FROM stdin;
\.


--
-- Data for Name: password_policies; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.password_policies (id, "minLength", "requireUppercase", "requireLowercase", "requireNumbers", "requireSpecialChars", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: performance_logs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.performance_logs (id, endpoint, method, "responseTime", "statusCode", "userId", "ipAddress", "userAgent", "createdAt", "eventId", "contestId", "categoryId") FROM stdin;
cmoolziuj0008yj5tw2hkf105	/stats	GET	24	403	cmoolzijc0004yj5tygs6qjz7	\N	\N	2026-05-02 17:21:43.723	\N	\N	\N
cmoolzj2f0009yj5t3cb9ioz8	/database/tables	GET	13	403	cmoolzijc0004yj5tygs6qjz7	\N	\N	2026-05-02 17:21:44.008	\N	\N	\N
cmoolzwiy00031p2em398yrmh	/event/:eventId	POST	177	404	cmoolzwcp00021p2eko3aaqoh	\N	\N	2026-05-02 17:22:01.45	\N	\N	\N
cmoolzwn000051p2e8p5z3hc0	/event/:eventId	DELETE	15	400	cmoolzwcp00021p2eko3aaqoh	\N	\N	2026-05-02 17:22:01.597	\N	\N	\N
cmoom03ne000h3zp0q4lhqj4k	/	POST	97	201	cmoom038900023zp08z8ykc14	\N	\N	2026-05-02 17:22:10.682	\N	\N	\N
cmoom03xn000n3zp0y5ydqaqv	/api/assignments/judges/cmoom039100083zp039oejs6k	GET	19	404	cmoom038900023zp08z8ykc14	\N	\N	2026-05-02 17:22:11.052	\N	\N	\N
cmoom0alb0009t7pqpac43h4q	/api/audit/logs	GET	14	404	cmoom0akl0008t7pqbbalr12i	\N	\N	2026-05-02 17:22:19.679	\N	\N	\N
cmoom0amm000at7pq57c967iq	/api/audit/user/test-user-id	GET	12	404	cmoom0a560002t7pqv8p5qpdh	\N	\N	2026-05-02 17:22:19.727	\N	\N	\N
cmoom0hip0003x5jtplfb7aot	/api/auditor-certification/verify/test-cert-id	POST	36	404	cmoom0h150002x5jtdld0geuc	\N	\N	2026-05-02 17:22:28.657	\N	\N	\N
cmoom0hjx0004x5jtrcyh5w9g	/api/auditor-certification/test-cert-id	DELETE	26	404	cmoom0h150002x5jtdld0geuc	\N	\N	2026-05-02 17:22:28.7	\N	\N	\N
cmoom0rdc000f4rbehn5uyqsn	/login	POST	26	401	\N	\N	\N	2026-05-02 17:22:41.424	\N	\N	\N
cmoom0rdt000g4rbezwn3yup0	/login	POST	8	422	\N	\N	\N	2026-05-02 17:22:41.441	\N	\N	\N
cmoom0ren000h4rbeukci4dlj	/login	POST	7	422	\N	\N	\N	2026-05-02 17:22:41.471	\N	\N	\N
cmoom0rmt000m4rbem8qqjmur	/login	POST	109	401	\N	\N	\N	2026-05-02 17:22:41.765	\N	\N	\N
cmoom0rtx000q4rbemcn7yxjr	/profile	GET	9	401	\N	\N	\N	2026-05-02 17:22:42.021	\N	\N	\N
cmoom0s9300124rbeu1pa4kuq	/reset-password	POST	8	400	\N	\N	\N	2026-05-02 17:22:42.567	\N	\N	\N
cmoom0s9i00134rbeq365xe1q	/reset-password	POST	6	422	\N	\N	\N	2026-05-02 17:22:42.582	\N	\N	\N
cmoom0zl100086xgebj3y8gar	/backup/settings	GET	121	401	\N	\N	\N	2026-05-02 17:22:52.07	\N	\N	\N
cmoom164t0008147fpl72ih2g	/bio/contestants/cmoom15v00004147fefkqq5xs	PUT	8	401	\N	\N	\N	2026-05-02 17:23:00.558	\N	\N	\N
cmoom1clz0008j1bn5kmftu4a	/login	POST	245	200	\N	\N	\N	2026-05-02 17:23:08.952	\N	\N	\N
cmoom1cuk000cj1bn8eghln07	/score-removal	GET	7	401	\N	\N	\N	2026-05-02 17:23:09.26	\N	\N	\N
cmoom1cv2000dj1bn79ulrpy0	/score-removal	POST	7	401	\N	\N	\N	2026-05-02 17:23:09.278	\N	\N	\N
cmoom1pyf0009wf6n7a86wz72	/login	POST	239	200	\N	\N	\N	2026-05-02 17:23:26.248	\N	\N	\N
cmoom1qd6000jwf6ns2nva209	/contest/cmoom1pqa0005wf6nczdptep0	POST	7	401	\N	\N	\N	2026-05-02 17:23:26.779	\N	\N	\N
cmoom1qnb000swf6nio5kuyrl	/contest/cmoom1pqa0005wf6nczdptep0	GET	8	401	\N	\N	\N	2026-05-02 17:23:27.143	\N	\N	\N
cmoom23gn0006y96c2lgjz22j	/api/category-types/test-type-id	PUT	26	404	cmoom236k0002y96c3nkj592l	\N	\N	2026-05-02 17:23:43.752	\N	\N	\N
cmoom2a33000bu3c278reckx7	/certification	POST	8	401	\N	\N	\N	2026-05-02 17:23:52.336	\N	\N	\N
cmoom2h230006ls8lyhwy833g	/commentary/test-commentary-id	DELETE	9	503	\N	\N	\N	2026-05-02 17:24:01.371	\N	\N	\N
cmoom2ngb0003kgtta4dm7tlc	/api/contest-certification	POST	159	404	cmoom2n9r0002kgtt8nx8v3uq	\N	\N	2026-05-02 17:24:09.659	\N	\N	\N
cmoom2udw000brc2uxlont5ty	/event/cmoom2u380003rc2uzffrttyl	POST	9	401	\N	\N	\N	2026-05-02 17:24:18.644	\N	\N	\N
cmoom2uh1000crc2up0q7unxn	/event/cmoom2u380003rc2uzffrttyl	GET	8	401	\N	\N	\N	2026-05-02 17:24:18.758	\N	\N	\N
cmoom2ui7000drc2u0jmpkmn4	/:id	GET	32	200	cmoom2u310002rc2uyko3xgn5	\N	\N	2026-05-02 17:24:18.799	\N	\N	\N
cmoom2uls000frc2ucltia4yb	/:id	PUT	30	200	cmoom2u310002rc2uyko3xgn5	\N	\N	2026-05-02 17:24:18.929	\N	\N	\N
cmoom30x6000ajki5ft3js52o	/:entityType	POST	18	201	cmoom30po0002jki51pd4e2ok	\N	\N	2026-05-02 17:24:27.115	\N	\N	\N
cmoom30zx000ejki5fizjuzxr	/:entityType	POST	14	400	cmoom30po0002jki51pd4e2ok	\N	\N	2026-05-02 17:24:27.213	\N	\N	\N
cmoom311i000fjki5qepy1ipz	/:entityType	GET	22	200	cmoom30po0002jki51pd4e2ok	\N	\N	2026-05-02 17:24:27.27	\N	\N	\N
cmoom3199000njki5at4hqph8	/:entityType/:entityId/values	POST	14	400	cmoom30po0002jki51pd4e2ok	\N	\N	2026-05-02 17:24:27.549	\N	\N	\N
cmoom3epp000h7hdny81tafkp	/deduction/history	GET	9	401	\N	\N	\N	2026-05-02 17:24:44.989	\N	\N	\N
cmoom3l610004tw32yrgix2z4	/config/:id	PUT	21	200	cmoom3l070002tw322ibj8alh	\N	\N	2026-05-02 17:24:53.353	\N	\N	\N
cmoom3l7p0006tw32h4smyifn	/schedules	POST	21	201	cmoom3l070002tw322ibj8alh	\N	\N	2026-05-02 17:24:53.413	\N	\N	\N
cmoom3lor000btw32wi3433ig	/schedules	POST	13	400	cmoom3l070002tw322ibj8alh	\N	\N	2026-05-02 17:24:54.028	\N	\N	\N
cmoom3lsu000etw32ezlzd45w	/targets/:id/verify	POST	58	500	cmoom3l070002tw322ibj8alh	\N	\N	2026-05-02 17:24:54.174	\N	\N	\N
cmoom3lue000gtw3248ws17f8	/targets/:id	PUT	18	200	cmoom3l070002tw322ibj8alh	\N	\N	2026-05-02 17:24:54.23	\N	\N	\N
\.


--
-- Data for Name: permission_audit_logs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.permission_audit_logs (id, role, resource, operation, "previousVal", "newVal", "changedBy", "changedAt", reason, "tenantId") FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.push_subscriptions (id, "userId", "tenantId", endpoint, p256dh, auth, "expirationTime", "userAgent", "isActive", "lastUsedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: rate_limit_configs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.rate_limit_configs (id, name, tier, "tenantId", "userId", endpoint, "requestsPerHour", "requestsPerMinute", "burstLimit", enabled, priority, description, "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: report_instances; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.report_instances (id, "templateId", "generatedById", "generatedAt", data, format, name, type, "tenantId") FROM stdin;
\.


--
-- Data for Name: report_templates; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.report_templates (id, name, type, template, parameters, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.reports (id, name, type, parameters, format, "generatedBy", "filePath", "fileSize", status, "createdAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: review_contestant_certifications; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.review_contestant_certifications (id, "categoryId", "contestantId", "reviewedBy", "reviewerRole", "reviewedAt", comments, "tenantId") FROM stdin;
\.


--
-- Data for Name: review_judge_score_certifications; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.review_judge_score_certifications (id, "categoryId", "judgeId", "reviewedBy", "reviewerRole", "reviewedAt", comments, "tenantId") FROM stdin;
\.


--
-- Data for Name: role_assignments; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.role_assignments (id, "userId", role, "contestId", "eventId", "categoryId", "assignedAt", "assignedBy", notes, "isActive", "tenantId") FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.role_permissions (id, role, resource, operation, allowed, "createdAt", "updatedAt", "createdBy", "tenantId") FROM stdin;
\.


--
-- Data for Name: saved_searches; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.saved_searches (id, "userId", name, query, filters, "entityTypes", "isPublic", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: score_comments; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.score_comments (id, "scoreId", "criterionId", "contestantId", "judgeId", comment, "isPrivate", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: score_files; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.score_files (id, "categoryId", "judgeId", "contestantId", "fileName", "fileType", "filePath", "fileSize", "uploadedById", status, notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: score_governance_approvals; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.score_governance_approvals (id, "requestId", "approvedById", "approverRole", "approverBoardRoleSnapshot", "typedSignature", "drawnSignatureData", "signatureFilePath", "approvedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: score_governance_requests; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.score_governance_requests (id, "actionType", "scopeType", "targetCertificationLevel", "eventId", "contestId", "categoryId", "contestantId", "judgeId", "scoreId", reason, status, "requestedById", "requesterRole", "requesterBoardRoleSnapshot", "initiatorTypedSignature", "initiatorDrawnSignatureData", "initiatorSignatureFilePath", "requiredAdditionalApprovals", "executedAt", "executedById", "executionSummary", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: score_removal_requests; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.score_removal_requests (id, "categoryId", "judgeId", reason, status, "requestedBy", "requestedAt", "tallySignature", "tallySignedAt", "tallySignedBy", "auditorSignature", "auditorSignedAt", "auditorSignedBy", "boardSignature", "boardRoleSnapshot", "boardSignedAt", "boardSignedBy", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: scores; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.scores (id, "categoryId", "contestantId", "judgeId", "criterionId", score, deduction, "deductionReason", "createdAt", "updatedAt", "allowCommentEdit", "certifiedAt", "certifiedBy", comment, "isCertified", "isLocked", "lockedAt", "lockedBy", "tenantId") FROM stdin;
\.


--
-- Data for Name: search_analytics; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.search_analytics (id, query, "resultCount", "avgResponseTime", "searchCount", "lastSearched", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: search_history; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.search_history (id, "userId", query, filters, "entityTypes", "resultCount", "createdAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: security_settings; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.security_settings (id, "passwordMinLength", "passwordRequireUppercase", "passwordRequireLowercase", "passwordRequireNumbers", "passwordRequireSymbols", "passwordExpiryDays", "maxLoginAttempts", "lockoutDurationMinutes", "requireTwoFactor", "sessionTimeoutMinutes", "enableIpWhitelist", "allowedIps", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.system_settings (id, key, value, description, category, "tenantId", "updatedAt", "updatedBy") FROM stdin;
\.


--
-- Data for Name: tally_master_assignments; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.tally_master_assignments (id, "userId", "categoryId", "contestId", "eventId", status, "assignedAt", "assignedBy", notes, "tenantId") FROM stdin;
\.


--
-- Data for Name: template_criteria; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.template_criteria (id, "templateId", name, "maxScore", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.tenants (id, name, slug, domain, "isActive", settings, "maxUsers", "maxEvents", "maxStorage", "planType", "subscriptionStatus", "subscriptionEndsAt", "scoringType", "createdAt", "updatedAt") FROM stdin;
cmoolzi8y0000yj5tgf7svd0x	Test Utils Tenant	test-utils-tenant	\N	t	\N	\N	\N	\N	enterprise	active	\N	STRAIGHT	2026-05-02 17:21:42.946	2026-05-02 17:24:53.029
\.


--
-- Data for Name: theme_settings; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.theme_settings (id, "primaryColor", "secondaryColor", "logoPath", "faviconPath", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: user_field_configurations; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.user_field_configurations (id, "fieldName", "isVisible", "isRequired", "order") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.users (id, name, "preferredName", email, password, role, "boardRole", gender, pronouns, "judgeId", "contestantId", "sessionVersion", "isActive", "lastLoginAt", "judgeBio", "judgeSpecialties", "judgeCertifications", "contestantBio", "contestantNumber", "contestantAge", "contestantSchool", bio, "imagePath", phone, address, timezone, language, "notificationSettings", "smsPhone", "smsEnabled", privacy, "createdAt", "updatedAt", "navigationPreferences", city, state, country, "tenantId", "isSuperAdmin", "mfaBackupCodes", "mfaEnabled", "mfaEnrolledAt", "mfaMethod", "mfaSecret") FROM stdin;
cmoom3l070002tw322ibj8alh	DR Admin	\N	dr-admin@test.com	hashedpassword	ADMIN	\N	\N	\N	\N	\N	1	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	UTC	en	\N	\N	f	\N	2026-05-02 17:24:53.142	2026-05-02 17:24:53.142	\N	\N	\N	\N	cmoolzi8y0000yj5tgf7svd0x	f	\N	f	\N	totp	\N
\.


--
-- Data for Name: webhook_configs; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.webhook_configs (id, "tenantId", name, url, events, enabled, secret, headers, "retryAttempts", timeout, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.webhook_deliveries (id, "webhookId", "eventId", status, "attemptCount", "lastAttemptAt", "responseStatus", "responseBody", "errorMessage", "createdAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: winner_signatures; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.winner_signatures (id, "categoryId", "contestId", "eventId", "userId", "userRole", signature, "signedAt", "ipAddress", "userAgent", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: workflow_instances; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.workflow_instances (id, "templateId", "tenantId", "entityType", "entityId", "currentStepId", status, "startedAt", "completedAt", metadata) FROM stdin;
\.


--
-- Data for Name: workflow_step_executions; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.workflow_step_executions (id, "instanceId", "stepId", status, "startedAt", "completedAt", "completedBy", "approvalStatus", comments, metadata, "tenantId") FROM stdin;
\.


--
-- Data for Name: workflow_steps; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.workflow_steps (id, "templateId", name, description, "stepOrder", "requiredRole", "autoAdvance", "requireApproval", conditions, actions, "notifyRoles", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: workflow_templates; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.workflow_templates (id, "tenantId", name, description, type, "isDefault", "isActive", config, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: workflow_transitions; Type: TABLE DATA; Schema: public; Owner: event_manager
--

COPY public.workflow_transitions (id, "fromStepId", "toStepId", condition, "transitionType", priority, "createdAt", "tenantId") FROM stdin;
\.


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: archived_events archived_events_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.archived_events
    ADD CONSTRAINT archived_events_pkey PRIMARY KEY (id);


--
-- Name: assignments assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auditor_assignments auditor_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.auditor_assignments
    ADD CONSTRAINT auditor_assignments_pkey PRIMARY KEY (id);


--
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_schedules backup_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.backup_schedules
    ADD CONSTRAINT backup_schedules_pkey PRIMARY KEY (id);


--
-- Name: backup_settings backup_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.backup_settings
    ADD CONSTRAINT backup_settings_pkey PRIMARY KEY (id);


--
-- Name: backup_targets backup_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.backup_targets
    ADD CONSTRAINT backup_targets_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: category_certifications category_certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_certifications
    ADD CONSTRAINT category_certifications_pkey PRIMARY KEY (id);


--
-- Name: category_contestants category_contestants_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_contestants
    ADD CONSTRAINT category_contestants_pkey PRIMARY KEY ("categoryId", "contestantId");


--
-- Name: category_judges category_judges_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_judges
    ADD CONSTRAINT category_judges_pkey PRIMARY KEY ("categoryId", "judgeId");


--
-- Name: category_templates category_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_templates
    ADD CONSTRAINT category_templates_pkey PRIMARY KEY (id);


--
-- Name: category_types category_types_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_types
    ADD CONSTRAINT category_types_pkey PRIMARY KEY (id);


--
-- Name: certifications certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.certifications
    ADD CONSTRAINT certifications_pkey PRIMARY KEY (id);


--
-- Name: contest_certifications contest_certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contest_certifications
    ADD CONSTRAINT contest_certifications_pkey PRIMARY KEY (id);


--
-- Name: contest_contestants contest_contestants_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contest_contestants
    ADD CONSTRAINT contest_contestants_pkey PRIMARY KEY ("contestId", "contestantId");


--
-- Name: contest_judges contest_judges_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contest_judges
    ADD CONSTRAINT contest_judges_pkey PRIMARY KEY ("contestId", "judgeId");


--
-- Name: contestants contestants_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contestants
    ADD CONSTRAINT contestants_pkey PRIMARY KEY (id);


--
-- Name: contests contests_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contests
    ADD CONSTRAINT contests_pkey PRIMARY KEY (id);


--
-- Name: criteria criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.criteria
    ADD CONSTRAINT criteria_pkey PRIMARY KEY (id);


--
-- Name: custom_field_values custom_field_values_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: deduction_approvals deduction_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.deduction_approvals
    ADD CONSTRAINT deduction_approvals_pkey PRIMARY KEY (id);


--
-- Name: deduction_requests deduction_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.deduction_requests
    ADD CONSTRAINT deduction_requests_pkey PRIMARY KEY (id);


--
-- Name: dr_configs dr_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.dr_configs
    ADD CONSTRAINT dr_configs_pkey PRIMARY KEY (id);


--
-- Name: dr_metrics dr_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.dr_metrics
    ADD CONSTRAINT dr_metrics_pkey PRIMARY KEY (id);


--
-- Name: dr_test_logs dr_test_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.dr_test_logs
    ADD CONSTRAINT dr_test_logs_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: email_settings email_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.email_settings
    ADD CONSTRAINT email_settings_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: emcee_scripts emcee_scripts_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.emcee_scripts
    ADD CONSTRAINT emcee_scripts_pkey PRIMARY KEY (id);


--
-- Name: error_logs error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.error_logs
    ADD CONSTRAINT error_logs_pkey PRIMARY KEY (id);


--
-- Name: event_logs event_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.event_logs
    ADD CONSTRAINT event_logs_pkey PRIMARY KEY (id);


--
-- Name: event_templates event_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.event_templates
    ADD CONSTRAINT event_templates_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: idempotency_records idempotency_records_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.idempotency_records
    ADD CONSTRAINT idempotency_records_pkey PRIMARY KEY (id);


--
-- Name: judge_certifications judge_certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_certifications
    ADD CONSTRAINT judge_certifications_pkey PRIMARY KEY (id);


--
-- Name: judge_comments judge_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_comments
    ADD CONSTRAINT judge_comments_pkey PRIMARY KEY (id);


--
-- Name: judge_contestant_certifications judge_contestant_certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_contestant_certifications
    ADD CONSTRAINT judge_contestant_certifications_pkey PRIMARY KEY (id);


--
-- Name: judge_score_removal_requests judge_score_removal_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_score_removal_requests
    ADD CONSTRAINT judge_score_removal_requests_pkey PRIMARY KEY (id);


--
-- Name: judge_uncertification_requests judge_uncertification_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_uncertification_requests
    ADD CONSTRAINT judge_uncertification_requests_pkey PRIMARY KEY (id);


--
-- Name: judges judges_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judges
    ADD CONSTRAINT judges_pkey PRIMARY KEY (id);


--
-- Name: logging_settings logging_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.logging_settings
    ADD CONSTRAINT logging_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_digests notification_digests_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.notification_digests
    ADD CONSTRAINT notification_digests_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: overall_deductions overall_deductions_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.overall_deductions
    ADD CONSTRAINT overall_deductions_pkey PRIMARY KEY (id);


--
-- Name: password_histories password_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.password_histories
    ADD CONSTRAINT password_histories_pkey PRIMARY KEY (id);


--
-- Name: password_policies password_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.password_policies
    ADD CONSTRAINT password_policies_pkey PRIMARY KEY (id);


--
-- Name: performance_logs performance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.performance_logs
    ADD CONSTRAINT performance_logs_pkey PRIMARY KEY (id);


--
-- Name: permission_audit_logs permission_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.permission_audit_logs
    ADD CONSTRAINT permission_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_configs rate_limit_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.rate_limit_configs
    ADD CONSTRAINT rate_limit_configs_pkey PRIMARY KEY (id);


--
-- Name: report_instances report_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.report_instances
    ADD CONSTRAINT report_instances_pkey PRIMARY KEY (id);


--
-- Name: report_templates report_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.report_templates
    ADD CONSTRAINT report_templates_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: review_contestant_certifications review_contestant_certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.review_contestant_certifications
    ADD CONSTRAINT review_contestant_certifications_pkey PRIMARY KEY (id);


--
-- Name: review_judge_score_certifications review_judge_score_certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.review_judge_score_certifications
    ADD CONSTRAINT review_judge_score_certifications_pkey PRIMARY KEY (id);


--
-- Name: role_assignments role_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT role_assignments_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: saved_searches saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_pkey PRIMARY KEY (id);


--
-- Name: score_comments score_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_comments
    ADD CONSTRAINT score_comments_pkey PRIMARY KEY (id);


--
-- Name: score_files score_files_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_files
    ADD CONSTRAINT score_files_pkey PRIMARY KEY (id);


--
-- Name: score_governance_approvals score_governance_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_approvals
    ADD CONSTRAINT score_governance_approvals_pkey PRIMARY KEY (id);


--
-- Name: score_governance_requests score_governance_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_requests
    ADD CONSTRAINT score_governance_requests_pkey PRIMARY KEY (id);


--
-- Name: score_removal_requests score_removal_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_removal_requests
    ADD CONSTRAINT score_removal_requests_pkey PRIMARY KEY (id);


--
-- Name: scores scores_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT scores_pkey PRIMARY KEY (id);


--
-- Name: search_analytics search_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.search_analytics
    ADD CONSTRAINT search_analytics_pkey PRIMARY KEY (id);


--
-- Name: search_history search_history_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT search_history_pkey PRIMARY KEY (id);


--
-- Name: security_settings security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.security_settings
    ADD CONSTRAINT security_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tally_master_assignments tally_master_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.tally_master_assignments
    ADD CONSTRAINT tally_master_assignments_pkey PRIMARY KEY (id);


--
-- Name: template_criteria template_criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.template_criteria
    ADD CONSTRAINT template_criteria_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: theme_settings theme_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.theme_settings
    ADD CONSTRAINT theme_settings_pkey PRIMARY KEY (id);


--
-- Name: user_field_configurations user_field_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.user_field_configurations
    ADD CONSTRAINT user_field_configurations_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_configs webhook_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.webhook_configs
    ADD CONSTRAINT webhook_configs_pkey PRIMARY KEY (id);


--
-- Name: webhook_deliveries webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: winner_signatures winner_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.winner_signatures
    ADD CONSTRAINT winner_signatures_pkey PRIMARY KEY (id);


--
-- Name: workflow_instances workflow_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.workflow_instances
    ADD CONSTRAINT workflow_instances_pkey PRIMARY KEY (id);


--
-- Name: workflow_step_executions workflow_step_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.workflow_step_executions
    ADD CONSTRAINT workflow_step_executions_pkey PRIMARY KEY (id);


--
-- Name: workflow_steps workflow_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_pkey PRIMARY KEY (id);


--
-- Name: workflow_templates workflow_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.workflow_templates
    ADD CONSTRAINT workflow_templates_pkey PRIMARY KEY (id);


--
-- Name: workflow_transitions workflow_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.workflow_transitions
    ADD CONSTRAINT workflow_transitions_pkey PRIMARY KEY (id);


--
-- Name: activity_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "activity_logs_createdAt_idx" ON public.activity_logs USING btree ("createdAt");


--
-- Name: activity_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "activity_logs_tenantId_idx" ON public.activity_logs USING btree ("tenantId");


--
-- Name: activity_logs_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "activity_logs_userId_idx" ON public.activity_logs USING btree ("userId");


--
-- Name: archived_events_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "archived_events_eventId_idx" ON public.archived_events USING btree ("eventId");


--
-- Name: archived_events_tenantId_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "archived_events_tenantId_eventId_idx" ON public.archived_events USING btree ("tenantId", "eventId");


--
-- Name: archived_events_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "archived_events_tenantId_idx" ON public.archived_events USING btree ("tenantId");


--
-- Name: assignments_contestId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "assignments_contestId_categoryId_idx" ON public.assignments USING btree ("contestId", "categoryId");


--
-- Name: assignments_judgeId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "assignments_judgeId_status_idx" ON public.assignments USING btree ("judgeId", status);


--
-- Name: assignments_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "assignments_tenantId_idx" ON public.assignments USING btree ("tenantId");


--
-- Name: assignments_tenantId_judgeId_categoryId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "assignments_tenantId_judgeId_categoryId_key" ON public.assignments USING btree ("tenantId", "judgeId", "categoryId");


--
-- Name: assignments_tenantId_judgeId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "assignments_tenantId_judgeId_status_idx" ON public.assignments USING btree ("tenantId", "judgeId", status);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "audit_logs_entityType_entityId_idx" ON public.audit_logs USING btree ("entityType", "entityId");


--
-- Name: audit_logs_tenantId_action_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "audit_logs_tenantId_action_idx" ON public.audit_logs USING btree ("tenantId", action);


--
-- Name: audit_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "audit_logs_tenantId_idx" ON public.audit_logs USING btree ("tenantId");


--
-- Name: audit_logs_tenantId_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "audit_logs_tenantId_userId_idx" ON public.audit_logs USING btree ("tenantId", "userId");


--
-- Name: audit_logs_timestamp_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX audit_logs_timestamp_idx ON public.audit_logs USING btree ("timestamp");


--
-- Name: audit_logs_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "audit_logs_userId_idx" ON public.audit_logs USING btree ("userId");


--
-- Name: auditor_assignments_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "auditor_assignments_eventId_idx" ON public.auditor_assignments USING btree ("eventId");


--
-- Name: auditor_assignments_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "auditor_assignments_tenantId_idx" ON public.auditor_assignments USING btree ("tenantId");


--
-- Name: auditor_assignments_tenantId_userId_categoryId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "auditor_assignments_tenantId_userId_categoryId_key" ON public.auditor_assignments USING btree ("tenantId", "userId", "categoryId");


--
-- Name: auditor_assignments_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "auditor_assignments_userId_idx" ON public.auditor_assignments USING btree ("userId");


--
-- Name: backup_logs_startedAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "backup_logs_startedAt_idx" ON public.backup_logs USING btree ("startedAt");


--
-- Name: backup_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "backup_logs_tenantId_idx" ON public.backup_logs USING btree ("tenantId");


--
-- Name: backup_logs_tenantId_type_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "backup_logs_tenantId_type_status_idx" ON public.backup_logs USING btree ("tenantId", type, status);


--
-- Name: backup_logs_type_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX backup_logs_type_status_idx ON public.backup_logs USING btree (type, status);


--
-- Name: backup_schedules_enabled_nextRunAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "backup_schedules_enabled_nextRunAt_idx" ON public.backup_schedules USING btree (enabled, "nextRunAt");


--
-- Name: backup_schedules_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "backup_schedules_tenantId_idx" ON public.backup_schedules USING btree ("tenantId");


--
-- Name: backup_targets_enabled_priority_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX backup_targets_enabled_priority_idx ON public.backup_targets USING btree (enabled, priority);


--
-- Name: backup_targets_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "backup_targets_tenantId_idx" ON public.backup_targets USING btree ("tenantId");


--
-- Name: categories_contestId_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "categories_contestId_createdAt_idx" ON public.categories USING btree ("contestId", "createdAt");


--
-- Name: categories_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "categories_contestId_idx" ON public.categories USING btree ("contestId");


--
-- Name: categories_tenantId_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "categories_tenantId_contestId_idx" ON public.categories USING btree ("tenantId", "contestId");


--
-- Name: categories_tenantId_deletedAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "categories_tenantId_deletedAt_idx" ON public.categories USING btree ("tenantId", "deletedAt");


--
-- Name: categories_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "categories_tenantId_idx" ON public.categories USING btree ("tenantId");


--
-- Name: category_certifications_categoryId_role_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_certifications_categoryId_role_idx" ON public.category_certifications USING btree ("categoryId", role);


--
-- Name: category_certifications_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_certifications_tenantId_categoryId_idx" ON public.category_certifications USING btree ("tenantId", "categoryId");


--
-- Name: category_certifications_tenantId_categoryId_role_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_certifications_tenantId_categoryId_role_userId_idx" ON public.category_certifications USING btree ("tenantId", "categoryId", role, "userId");


--
-- Name: category_certifications_tenantId_categoryId_role_userId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "category_certifications_tenantId_categoryId_role_userId_key" ON public.category_certifications USING btree ("tenantId", "categoryId", role, "userId");


--
-- Name: category_certifications_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_certifications_tenantId_idx" ON public.category_certifications USING btree ("tenantId");


--
-- Name: category_contestants_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_contestants_categoryId_idx" ON public.category_contestants USING btree ("categoryId");


--
-- Name: category_contestants_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_contestants_tenantId_categoryId_idx" ON public.category_contestants USING btree ("tenantId", "categoryId");


--
-- Name: category_contestants_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_contestants_tenantId_idx" ON public.category_contestants USING btree ("tenantId");


--
-- Name: category_judges_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_judges_categoryId_idx" ON public.category_judges USING btree ("categoryId");


--
-- Name: category_judges_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_judges_tenantId_categoryId_idx" ON public.category_judges USING btree ("tenantId", "categoryId");


--
-- Name: category_judges_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_judges_tenantId_idx" ON public.category_judges USING btree ("tenantId");


--
-- Name: category_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_templates_tenantId_idx" ON public.category_templates USING btree ("tenantId");


--
-- Name: category_templates_tenantId_name_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "category_templates_tenantId_name_idx" ON public.category_templates USING btree ("tenantId", name);


--
-- Name: category_types_name_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX category_types_name_key ON public.category_types USING btree (name);


--
-- Name: certifications_tenantId_categoryId_contestId_eventId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "certifications_tenantId_categoryId_contestId_eventId_key" ON public.certifications USING btree ("tenantId", "categoryId", "contestId", "eventId");


--
-- Name: certifications_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "certifications_tenantId_idx" ON public.certifications USING btree ("tenantId");


--
-- Name: certifications_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "certifications_tenantId_status_idx" ON public.certifications USING btree ("tenantId", status);


--
-- Name: contest_certifications_contestId_role_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contest_certifications_contestId_role_idx" ON public.contest_certifications USING btree ("contestId", role);


--
-- Name: contest_certifications_tenantId_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contest_certifications_tenantId_contestId_idx" ON public.contest_certifications USING btree ("tenantId", "contestId");


--
-- Name: contest_certifications_tenantId_contestId_role_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "contest_certifications_tenantId_contestId_role_key" ON public.contest_certifications USING btree ("tenantId", "contestId", role);


--
-- Name: contest_certifications_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contest_certifications_tenantId_idx" ON public.contest_certifications USING btree ("tenantId");


--
-- Name: contest_contestants_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contest_contestants_contestId_idx" ON public.contest_contestants USING btree ("contestId");


--
-- Name: contest_contestants_tenantId_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contest_contestants_tenantId_contestId_idx" ON public.contest_contestants USING btree ("tenantId", "contestId");


--
-- Name: contest_contestants_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contest_contestants_tenantId_idx" ON public.contest_contestants USING btree ("tenantId");


--
-- Name: contest_judges_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contest_judges_contestId_idx" ON public.contest_judges USING btree ("contestId");


--
-- Name: contest_judges_tenantId_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contest_judges_tenantId_contestId_idx" ON public.contest_judges USING btree ("tenantId", "contestId");


--
-- Name: contest_judges_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contest_judges_tenantId_idx" ON public.contest_judges USING btree ("tenantId");


--
-- Name: contestants_tenantId_contestantNumber_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contestants_tenantId_contestantNumber_idx" ON public.contestants USING btree ("tenantId", "contestantNumber");


--
-- Name: contestants_tenantId_email_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "contestants_tenantId_email_key" ON public.contestants USING btree ("tenantId", email);


--
-- Name: contestants_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contestants_tenantId_idx" ON public.contestants USING btree ("tenantId");


--
-- Name: contests_eventId_archived_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contests_eventId_archived_idx" ON public.contests USING btree ("eventId", archived);


--
-- Name: contests_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contests_eventId_idx" ON public.contests USING btree ("eventId");


--
-- Name: contests_tenantId_deletedAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contests_tenantId_deletedAt_idx" ON public.contests USING btree ("tenantId", "deletedAt");


--
-- Name: contests_tenantId_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contests_tenantId_eventId_idx" ON public.contests USING btree ("tenantId", "eventId");


--
-- Name: contests_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "contests_tenantId_idx" ON public.contests USING btree ("tenantId");


--
-- Name: criteria_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "criteria_categoryId_idx" ON public.criteria USING btree ("categoryId");


--
-- Name: criteria_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "criteria_tenantId_categoryId_idx" ON public.criteria USING btree ("tenantId", "categoryId");


--
-- Name: criteria_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "criteria_tenantId_idx" ON public.criteria USING btree ("tenantId");


--
-- Name: custom_field_values_customFieldId_entityId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "custom_field_values_customFieldId_entityId_idx" ON public.custom_field_values USING btree ("customFieldId", "entityId");


--
-- Name: custom_field_values_entityId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "custom_field_values_entityId_idx" ON public.custom_field_values USING btree ("entityId");


--
-- Name: custom_field_values_tenantId_customFieldId_entityId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "custom_field_values_tenantId_customFieldId_entityId_key" ON public.custom_field_values USING btree ("tenantId", "customFieldId", "entityId");


--
-- Name: custom_field_values_tenantId_entityId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "custom_field_values_tenantId_entityId_idx" ON public.custom_field_values USING btree ("tenantId", "entityId");


--
-- Name: custom_field_values_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "custom_field_values_tenantId_idx" ON public.custom_field_values USING btree ("tenantId");


--
-- Name: custom_fields_entityType_active_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "custom_fields_entityType_active_idx" ON public.custom_fields USING btree ("entityType", active);


--
-- Name: custom_fields_key_entityType_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "custom_fields_key_entityType_idx" ON public.custom_fields USING btree (key, "entityType");


--
-- Name: custom_fields_tenantId_entityType_active_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "custom_fields_tenantId_entityType_active_idx" ON public.custom_fields USING btree ("tenantId", "entityType", active);


--
-- Name: custom_fields_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "custom_fields_tenantId_idx" ON public.custom_fields USING btree ("tenantId");


--
-- Name: custom_fields_tenantId_key_entityType_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "custom_fields_tenantId_key_entityType_key" ON public.custom_fields USING btree ("tenantId", key, "entityType");


--
-- Name: deduction_approvals_requestId_approvedById_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "deduction_approvals_requestId_approvedById_idx" ON public.deduction_approvals USING btree ("requestId", "approvedById");


--
-- Name: deduction_approvals_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "deduction_approvals_tenantId_idx" ON public.deduction_approvals USING btree ("tenantId");


--
-- Name: deduction_approvals_tenantId_requestId_approvedById_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "deduction_approvals_tenantId_requestId_approvedById_key" ON public.deduction_approvals USING btree ("tenantId", "requestId", "approvedById");


--
-- Name: deduction_approvals_tenantId_requestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "deduction_approvals_tenantId_requestId_idx" ON public.deduction_approvals USING btree ("tenantId", "requestId");


--
-- Name: deduction_requests_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "deduction_requests_categoryId_idx" ON public.deduction_requests USING btree ("categoryId");


--
-- Name: deduction_requests_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "deduction_requests_tenantId_categoryId_idx" ON public.deduction_requests USING btree ("tenantId", "categoryId");


--
-- Name: deduction_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "deduction_requests_tenantId_idx" ON public.deduction_requests USING btree ("tenantId");


--
-- Name: deduction_requests_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "deduction_requests_tenantId_status_idx" ON public.deduction_requests USING btree ("tenantId", status);


--
-- Name: dr_configs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "dr_configs_tenantId_idx" ON public.dr_configs USING btree ("tenantId");


--
-- Name: dr_metrics_metricType_timestamp_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "dr_metrics_metricType_timestamp_idx" ON public.dr_metrics USING btree ("metricType", "timestamp");


--
-- Name: dr_metrics_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "dr_metrics_tenantId_idx" ON public.dr_metrics USING btree ("tenantId");


--
-- Name: dr_metrics_tenantId_metricType_timestamp_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "dr_metrics_tenantId_metricType_timestamp_idx" ON public.dr_metrics USING btree ("tenantId", "metricType", "timestamp");


--
-- Name: dr_test_logs_startedAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "dr_test_logs_startedAt_idx" ON public.dr_test_logs USING btree ("startedAt");


--
-- Name: dr_test_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "dr_test_logs_tenantId_idx" ON public.dr_test_logs USING btree ("tenantId");


--
-- Name: dr_test_logs_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "dr_test_logs_tenantId_status_idx" ON public.dr_test_logs USING btree ("tenantId", status);


--
-- Name: email_logs_sentAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "email_logs_sentAt_idx" ON public.email_logs USING btree ("sentAt");


--
-- Name: email_logs_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX email_logs_status_idx ON public.email_logs USING btree (status);


--
-- Name: email_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "email_logs_tenantId_idx" ON public.email_logs USING btree ("tenantId");


--
-- Name: email_logs_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "email_logs_tenantId_status_idx" ON public.email_logs USING btree ("tenantId", status);


--
-- Name: email_logs_tenantId_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "email_logs_tenantId_userId_idx" ON public.email_logs USING btree ("tenantId", "userId");


--
-- Name: email_templates_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "email_templates_eventId_idx" ON public.email_templates USING btree ("eventId");


--
-- Name: email_templates_tenantId_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "email_templates_tenantId_eventId_idx" ON public.email_templates USING btree ("tenantId", "eventId");


--
-- Name: email_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "email_templates_tenantId_idx" ON public.email_templates USING btree ("tenantId");


--
-- Name: email_templates_tenantId_type_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "email_templates_tenantId_type_idx" ON public.email_templates USING btree ("tenantId", type);


--
-- Name: email_templates_type_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX email_templates_type_idx ON public.email_templates USING btree (type);


--
-- Name: emcee_scripts_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "emcee_scripts_categoryId_idx" ON public.emcee_scripts USING btree ("categoryId");


--
-- Name: emcee_scripts_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "emcee_scripts_contestId_idx" ON public.emcee_scripts USING btree ("contestId");


--
-- Name: emcee_scripts_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "emcee_scripts_eventId_idx" ON public.emcee_scripts USING btree ("eventId");


--
-- Name: emcee_scripts_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "emcee_scripts_tenantId_categoryId_idx" ON public.emcee_scripts USING btree ("tenantId", "categoryId");


--
-- Name: emcee_scripts_tenantId_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "emcee_scripts_tenantId_contestId_idx" ON public.emcee_scripts USING btree ("tenantId", "contestId");


--
-- Name: emcee_scripts_tenantId_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "emcee_scripts_tenantId_eventId_idx" ON public.emcee_scripts USING btree ("tenantId", "eventId");


--
-- Name: emcee_scripts_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "emcee_scripts_tenantId_idx" ON public.emcee_scripts USING btree ("tenantId");


--
-- Name: error_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "error_logs_createdAt_idx" ON public.error_logs USING btree ("createdAt");


--
-- Name: error_logs_level_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX error_logs_level_idx ON public.error_logs USING btree (level);


--
-- Name: error_logs_resolved_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX error_logs_resolved_idx ON public.error_logs USING btree (resolved);


--
-- Name: error_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "error_logs_tenantId_idx" ON public.error_logs USING btree ("tenantId");


--
-- Name: error_logs_tenantId_level_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "error_logs_tenantId_level_idx" ON public.error_logs USING btree ("tenantId", level);


--
-- Name: event_logs_correlationId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "event_logs_correlationId_idx" ON public.event_logs USING btree ("correlationId");


--
-- Name: event_logs_eventType_timestamp_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "event_logs_eventType_timestamp_idx" ON public.event_logs USING btree ("eventType", "timestamp");


--
-- Name: event_logs_processed_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX event_logs_processed_idx ON public.event_logs USING btree (processed);


--
-- Name: event_logs_tenantId_eventType_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "event_logs_tenantId_eventType_idx" ON public.event_logs USING btree ("tenantId", "eventType");


--
-- Name: event_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "event_logs_tenantId_idx" ON public.event_logs USING btree ("tenantId");


--
-- Name: event_logs_timestamp_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX event_logs_timestamp_idx ON public.event_logs USING btree ("timestamp");


--
-- Name: event_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "event_templates_tenantId_idx" ON public.event_templates USING btree ("tenantId");


--
-- Name: event_templates_tenantId_name_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "event_templates_tenantId_name_idx" ON public.event_templates USING btree ("tenantId", name);


--
-- Name: events_tenantId_archived_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "events_tenantId_archived_idx" ON public.events USING btree ("tenantId", archived);


--
-- Name: events_tenantId_deletedAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "events_tenantId_deletedAt_idx" ON public.events USING btree ("tenantId", "deletedAt");


--
-- Name: events_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "events_tenantId_idx" ON public.events USING btree ("tenantId");


--
-- Name: feature_flags_enabled_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX feature_flags_enabled_idx ON public.feature_flags USING btree (enabled);


--
-- Name: feature_flags_name_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX feature_flags_name_idx ON public.feature_flags USING btree (name);


--
-- Name: feature_flags_name_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX feature_flags_name_key ON public.feature_flags USING btree (name);


--
-- Name: files_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "files_categoryId_idx" ON public.files USING btree ("categoryId");


--
-- Name: files_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "files_contestId_idx" ON public.files USING btree ("contestId");


--
-- Name: files_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "files_eventId_idx" ON public.files USING btree ("eventId");


--
-- Name: files_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "files_tenantId_categoryId_idx" ON public.files USING btree ("tenantId", "categoryId");


--
-- Name: files_tenantId_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "files_tenantId_contestId_idx" ON public.files USING btree ("tenantId", "contestId");


--
-- Name: files_tenantId_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "files_tenantId_eventId_idx" ON public.files USING btree ("tenantId", "eventId");


--
-- Name: files_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "files_tenantId_idx" ON public.files USING btree ("tenantId");


--
-- Name: files_tenantId_uploadedBy_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "files_tenantId_uploadedBy_idx" ON public.files USING btree ("tenantId", "uploadedBy");


--
-- Name: idempotency_records_tenantId_expiresAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "idempotency_records_tenantId_expiresAt_idx" ON public.idempotency_records USING btree ("tenantId", "expiresAt");


--
-- Name: idempotency_records_tenantId_status_updatedAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "idempotency_records_tenantId_status_updatedAt_idx" ON public.idempotency_records USING btree ("tenantId", status, "updatedAt");


--
-- Name: idx_categories_contest_id; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX idx_categories_contest_id ON public.categories USING btree ("contestId");


--
-- Name: idx_contestant_number; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX idx_contestant_number ON public.contestants USING btree ("contestantNumber");


--
-- Name: idx_contests_event_archived; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX idx_contests_event_archived ON public.contests USING btree ("eventId", archived);


--
-- Name: idx_contests_event_id; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX idx_contests_event_id ON public.contests USING btree ("eventId");


--
-- Name: judge_certifications_categoryId_judgeId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_certifications_categoryId_judgeId_idx" ON public.judge_certifications USING btree ("categoryId", "judgeId");


--
-- Name: judge_certifications_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_certifications_tenantId_categoryId_idx" ON public.judge_certifications USING btree ("tenantId", "categoryId");


--
-- Name: judge_certifications_tenantId_categoryId_judgeId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "judge_certifications_tenantId_categoryId_judgeId_key" ON public.judge_certifications USING btree ("tenantId", "categoryId", "judgeId");


--
-- Name: judge_certifications_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_certifications_tenantId_idx" ON public.judge_certifications USING btree ("tenantId");


--
-- Name: judge_comments_categoryId_contestantId_judgeId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_comments_categoryId_contestantId_judgeId_idx" ON public.judge_comments USING btree ("categoryId", "contestantId", "judgeId");


--
-- Name: judge_comments_tenantId_categoryId_contestantId_judgeId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "judge_comments_tenantId_categoryId_contestantId_judgeId_key" ON public.judge_comments USING btree ("tenantId", "categoryId", "contestantId", "judgeId");


--
-- Name: judge_comments_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_comments_tenantId_categoryId_idx" ON public.judge_comments USING btree ("tenantId", "categoryId");


--
-- Name: judge_comments_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_comments_tenantId_idx" ON public.judge_comments USING btree ("tenantId");


--
-- Name: judge_contestant_certifications_categoryId_judgeId_contesta_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_contestant_certifications_categoryId_judgeId_contesta_idx" ON public.judge_contestant_certifications USING btree ("categoryId", "judgeId", "contestantId");


--
-- Name: judge_contestant_certifications_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_contestant_certifications_tenantId_categoryId_idx" ON public.judge_contestant_certifications USING btree ("tenantId", "categoryId");


--
-- Name: judge_contestant_certifications_tenantId_categoryId_judgeId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "judge_contestant_certifications_tenantId_categoryId_judgeId_key" ON public.judge_contestant_certifications USING btree ("tenantId", "categoryId", "judgeId", "contestantId");


--
-- Name: judge_contestant_certifications_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_contestant_certifications_tenantId_idx" ON public.judge_contestant_certifications USING btree ("tenantId");


--
-- Name: judge_score_removal_requests_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_score_removal_requests_categoryId_idx" ON public.judge_score_removal_requests USING btree ("categoryId");


--
-- Name: judge_score_removal_requests_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_score_removal_requests_tenantId_categoryId_idx" ON public.judge_score_removal_requests USING btree ("tenantId", "categoryId");


--
-- Name: judge_score_removal_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_score_removal_requests_tenantId_idx" ON public.judge_score_removal_requests USING btree ("tenantId");


--
-- Name: judge_score_removal_requests_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_score_removal_requests_tenantId_status_idx" ON public.judge_score_removal_requests USING btree ("tenantId", status);


--
-- Name: judge_uncertification_requests_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_uncertification_requests_categoryId_idx" ON public.judge_uncertification_requests USING btree ("categoryId");


--
-- Name: judge_uncertification_requests_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_uncertification_requests_tenantId_categoryId_idx" ON public.judge_uncertification_requests USING btree ("tenantId", "categoryId");


--
-- Name: judge_uncertification_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_uncertification_requests_tenantId_idx" ON public.judge_uncertification_requests USING btree ("tenantId");


--
-- Name: judge_uncertification_requests_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judge_uncertification_requests_tenantId_status_idx" ON public.judge_uncertification_requests USING btree ("tenantId", status);


--
-- Name: judges_tenantId_email_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "judges_tenantId_email_key" ON public.judges USING btree ("tenantId", email);


--
-- Name: judges_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "judges_tenantId_idx" ON public.judges USING btree ("tenantId");


--
-- Name: notification_digests_nextSendAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_digests_nextSendAt_idx" ON public.notification_digests USING btree ("nextSendAt");


--
-- Name: notification_digests_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_digests_tenantId_idx" ON public.notification_digests USING btree ("tenantId");


--
-- Name: notification_digests_tenantId_nextSendAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_digests_tenantId_nextSendAt_idx" ON public.notification_digests USING btree ("tenantId", "nextSendAt");


--
-- Name: notification_digests_tenantId_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_digests_tenantId_userId_idx" ON public.notification_digests USING btree ("tenantId", "userId");


--
-- Name: notification_digests_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_digests_userId_idx" ON public.notification_digests USING btree ("userId");


--
-- Name: notification_preferences_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_preferences_tenantId_idx" ON public.notification_preferences USING btree ("tenantId");


--
-- Name: notification_preferences_tenantId_userId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "notification_preferences_tenantId_userId_key" ON public.notification_preferences USING btree ("tenantId", "userId");


--
-- Name: notification_preferences_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_preferences_userId_idx" ON public.notification_preferences USING btree ("userId");


--
-- Name: notification_templates_name_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX notification_templates_name_idx ON public.notification_templates USING btree (name);


--
-- Name: notification_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_templates_tenantId_idx" ON public.notification_templates USING btree ("tenantId");


--
-- Name: notification_templates_tenantId_name_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "notification_templates_tenantId_name_key" ON public.notification_templates USING btree ("tenantId", name);


--
-- Name: notification_templates_tenantId_type_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_templates_tenantId_type_isActive_idx" ON public.notification_templates USING btree ("tenantId", type, "isActive");


--
-- Name: notification_templates_type_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notification_templates_type_isActive_idx" ON public.notification_templates USING btree (type, "isActive");


--
-- Name: notifications_deletedAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notifications_deletedAt_idx" ON public.notifications USING btree ("deletedAt");


--
-- Name: notifications_sentBy_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notifications_sentBy_createdAt_idx" ON public.notifications USING btree ("sentBy", "createdAt");


--
-- Name: notifications_templateId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notifications_templateId_idx" ON public.notifications USING btree ("templateId");


--
-- Name: notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notifications_tenantId_idx" ON public.notifications USING btree ("tenantId");


--
-- Name: notifications_tenantId_userId_read_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notifications_tenantId_userId_read_idx" ON public.notifications USING btree ("tenantId", "userId", read);


--
-- Name: notifications_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notifications_userId_createdAt_idx" ON public.notifications USING btree ("userId", "createdAt");


--
-- Name: notifications_userId_read_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "notifications_userId_read_idx" ON public.notifications USING btree ("userId", read);


--
-- Name: overall_deductions_categoryId_contestantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "overall_deductions_categoryId_contestantId_idx" ON public.overall_deductions USING btree ("categoryId", "contestantId");


--
-- Name: overall_deductions_tenantId_categoryId_contestantId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "overall_deductions_tenantId_categoryId_contestantId_key" ON public.overall_deductions USING btree ("tenantId", "categoryId", "contestantId");


--
-- Name: overall_deductions_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "overall_deductions_tenantId_categoryId_idx" ON public.overall_deductions USING btree ("tenantId", "categoryId");


--
-- Name: overall_deductions_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "overall_deductions_tenantId_idx" ON public.overall_deductions USING btree ("tenantId");


--
-- Name: password_histories_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "password_histories_createdAt_idx" ON public.password_histories USING btree ("createdAt");


--
-- Name: password_histories_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "password_histories_userId_idx" ON public.password_histories USING btree ("userId");


--
-- Name: permission_audit_logs_tenantId_changedAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "permission_audit_logs_tenantId_changedAt_idx" ON public.permission_audit_logs USING btree ("tenantId", "changedAt");


--
-- Name: push_subscriptions_tenantId_endpoint_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "push_subscriptions_tenantId_endpoint_key" ON public.push_subscriptions USING btree ("tenantId", endpoint);


--
-- Name: push_subscriptions_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "push_subscriptions_tenantId_idx" ON public.push_subscriptions USING btree ("tenantId");


--
-- Name: push_subscriptions_tenantId_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "push_subscriptions_tenantId_userId_idx" ON public.push_subscriptions USING btree ("tenantId", "userId");


--
-- Name: push_subscriptions_tenantId_userId_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "push_subscriptions_tenantId_userId_isActive_idx" ON public.push_subscriptions USING btree ("tenantId", "userId", "isActive");


--
-- Name: rate_limit_configs_enabled_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX rate_limit_configs_enabled_idx ON public.rate_limit_configs USING btree (enabled);


--
-- Name: rate_limit_configs_endpoint_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX rate_limit_configs_endpoint_idx ON public.rate_limit_configs USING btree (endpoint);


--
-- Name: rate_limit_configs_tenantId_endpoint_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "rate_limit_configs_tenantId_endpoint_idx" ON public.rate_limit_configs USING btree ("tenantId", endpoint);


--
-- Name: rate_limit_configs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "rate_limit_configs_tenantId_idx" ON public.rate_limit_configs USING btree ("tenantId");


--
-- Name: rate_limit_configs_tenantId_userId_endpoint_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "rate_limit_configs_tenantId_userId_endpoint_key" ON public.rate_limit_configs USING btree ("tenantId", "userId", endpoint);


--
-- Name: rate_limit_configs_tenantId_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "rate_limit_configs_tenantId_userId_idx" ON public.rate_limit_configs USING btree ("tenantId", "userId");


--
-- Name: rate_limit_configs_tier_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX rate_limit_configs_tier_idx ON public.rate_limit_configs USING btree (tier);


--
-- Name: rate_limit_configs_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "rate_limit_configs_userId_idx" ON public.rate_limit_configs USING btree ("userId");


--
-- Name: report_instances_tenantId_generatedAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "report_instances_tenantId_generatedAt_idx" ON public.report_instances USING btree ("tenantId", "generatedAt");


--
-- Name: report_instances_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "report_instances_tenantId_idx" ON public.report_instances USING btree ("tenantId");


--
-- Name: report_instances_tenantId_type_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "report_instances_tenantId_type_idx" ON public.report_instances USING btree ("tenantId", type);


--
-- Name: report_instances_type_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX report_instances_type_idx ON public.report_instances USING btree (type);


--
-- Name: report_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "report_templates_tenantId_idx" ON public.report_templates USING btree ("tenantId");


--
-- Name: report_templates_tenantId_type_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "report_templates_tenantId_type_idx" ON public.report_templates USING btree ("tenantId", type);


--
-- Name: report_templates_type_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX report_templates_type_idx ON public.report_templates USING btree (type);


--
-- Name: reports_tenantId_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "reports_tenantId_createdAt_idx" ON public.reports USING btree ("tenantId", "createdAt");


--
-- Name: reports_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "reports_tenantId_idx" ON public.reports USING btree ("tenantId");


--
-- Name: reports_tenantId_type_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "reports_tenantId_type_idx" ON public.reports USING btree ("tenantId", type);


--
-- Name: review_contestant_certifications_categoryId_contestantId_re_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "review_contestant_certifications_categoryId_contestantId_re_idx" ON public.review_contestant_certifications USING btree ("categoryId", "contestantId", "reviewedBy");


--
-- Name: review_contestant_certifications_tenantId_categoryId_contes_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "review_contestant_certifications_tenantId_categoryId_contes_key" ON public.review_contestant_certifications USING btree ("tenantId", "categoryId", "contestantId", "reviewedBy");


--
-- Name: review_contestant_certifications_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "review_contestant_certifications_tenantId_categoryId_idx" ON public.review_contestant_certifications USING btree ("tenantId", "categoryId");


--
-- Name: review_contestant_certifications_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "review_contestant_certifications_tenantId_idx" ON public.review_contestant_certifications USING btree ("tenantId");


--
-- Name: review_judge_score_certifications_categoryId_judgeId_review_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "review_judge_score_certifications_categoryId_judgeId_review_idx" ON public.review_judge_score_certifications USING btree ("categoryId", "judgeId", "reviewedBy");


--
-- Name: review_judge_score_certifications_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "review_judge_score_certifications_tenantId_categoryId_idx" ON public.review_judge_score_certifications USING btree ("tenantId", "categoryId");


--
-- Name: review_judge_score_certifications_tenantId_categoryId_judge_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "review_judge_score_certifications_tenantId_categoryId_judge_key" ON public.review_judge_score_certifications USING btree ("tenantId", "categoryId", "judgeId", "reviewedBy");


--
-- Name: review_judge_score_certifications_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "review_judge_score_certifications_tenantId_idx" ON public.review_judge_score_certifications USING btree ("tenantId");


--
-- Name: role_assignments_categoryId_role_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "role_assignments_categoryId_role_isActive_idx" ON public.role_assignments USING btree ("categoryId", role, "isActive");


--
-- Name: role_assignments_tenantId_categoryId_role_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "role_assignments_tenantId_categoryId_role_isActive_idx" ON public.role_assignments USING btree ("tenantId", "categoryId", role, "isActive");


--
-- Name: role_assignments_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "role_assignments_tenantId_idx" ON public.role_assignments USING btree ("tenantId");


--
-- Name: role_assignments_tenantId_userId_role_contestId_eventId_cat_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "role_assignments_tenantId_userId_role_contestId_eventId_cat_key" ON public.role_assignments USING btree ("tenantId", "userId", role, "contestId", "eventId", "categoryId");


--
-- Name: role_assignments_tenantId_userId_role_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "role_assignments_tenantId_userId_role_isActive_idx" ON public.role_assignments USING btree ("tenantId", "userId", role, "isActive");


--
-- Name: role_assignments_userId_role_contestId_eventId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "role_assignments_userId_role_contestId_eventId_categoryId_idx" ON public.role_assignments USING btree ("userId", role, "contestId", "eventId", "categoryId");


--
-- Name: role_assignments_userId_role_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "role_assignments_userId_role_isActive_idx" ON public.role_assignments USING btree ("userId", role, "isActive");


--
-- Name: role_permissions_resource_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX role_permissions_resource_idx ON public.role_permissions USING btree (resource);


--
-- Name: role_permissions_tenantId_role_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "role_permissions_tenantId_role_idx" ON public.role_permissions USING btree ("tenantId", role);


--
-- Name: role_permissions_tenantId_role_resource_operation_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "role_permissions_tenantId_role_resource_operation_key" ON public.role_permissions USING btree ("tenantId", role, resource, operation);


--
-- Name: saved_searches_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "saved_searches_tenantId_idx" ON public.saved_searches USING btree ("tenantId");


--
-- Name: saved_searches_tenantId_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "saved_searches_tenantId_userId_idx" ON public.saved_searches USING btree ("tenantId", "userId");


--
-- Name: saved_searches_tenantId_userId_isPublic_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "saved_searches_tenantId_userId_isPublic_idx" ON public.saved_searches USING btree ("tenantId", "userId", "isPublic");


--
-- Name: saved_searches_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "saved_searches_userId_idx" ON public.saved_searches USING btree ("userId");


--
-- Name: saved_searches_userId_isPublic_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "saved_searches_userId_isPublic_idx" ON public.saved_searches USING btree ("userId", "isPublic");


--
-- Name: score_comments_scoreId_criterionId_contestantId_judgeId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_comments_scoreId_criterionId_contestantId_judgeId_idx" ON public.score_comments USING btree ("scoreId", "criterionId", "contestantId", "judgeId");


--
-- Name: score_comments_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_comments_tenantId_idx" ON public.score_comments USING btree ("tenantId");


--
-- Name: score_comments_tenantId_scoreId_criterionId_contestantId_ju_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "score_comments_tenantId_scoreId_criterionId_contestantId_ju_key" ON public.score_comments USING btree ("tenantId", "scoreId", "criterionId", "contestantId", "judgeId");


--
-- Name: score_comments_tenantId_scoreId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_comments_tenantId_scoreId_idx" ON public.score_comments USING btree ("tenantId", "scoreId");


--
-- Name: score_files_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_files_categoryId_idx" ON public.score_files USING btree ("categoryId");


--
-- Name: score_files_contestantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_files_contestantId_idx" ON public.score_files USING btree ("contestantId");


--
-- Name: score_files_judgeId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_files_judgeId_idx" ON public.score_files USING btree ("judgeId");


--
-- Name: score_files_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX score_files_status_idx ON public.score_files USING btree (status);


--
-- Name: score_files_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_files_tenantId_categoryId_idx" ON public.score_files USING btree ("tenantId", "categoryId");


--
-- Name: score_files_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_files_tenantId_idx" ON public.score_files USING btree ("tenantId");


--
-- Name: score_files_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_files_tenantId_status_idx" ON public.score_files USING btree ("tenantId", status);


--
-- Name: score_files_tenantId_uploadedById_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_files_tenantId_uploadedById_idx" ON public.score_files USING btree ("tenantId", "uploadedById");


--
-- Name: score_files_uploadedById_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_files_uploadedById_idx" ON public.score_files USING btree ("uploadedById");


--
-- Name: score_governance_approvals_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_approvals_tenantId_idx" ON public.score_governance_approvals USING btree ("tenantId");


--
-- Name: score_governance_approvals_tenantId_requestId_approvedById_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "score_governance_approvals_tenantId_requestId_approvedById_key" ON public.score_governance_approvals USING btree ("tenantId", "requestId", "approvedById");


--
-- Name: score_governance_approvals_tenantId_requestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_approvals_tenantId_requestId_idx" ON public.score_governance_approvals USING btree ("tenantId", "requestId");


--
-- Name: score_governance_requests_tenantId_actionType_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_requests_tenantId_actionType_idx" ON public.score_governance_requests USING btree ("tenantId", "actionType");


--
-- Name: score_governance_requests_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_requests_tenantId_categoryId_idx" ON public.score_governance_requests USING btree ("tenantId", "categoryId");


--
-- Name: score_governance_requests_tenantId_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_requests_tenantId_contestId_idx" ON public.score_governance_requests USING btree ("tenantId", "contestId");


--
-- Name: score_governance_requests_tenantId_contestantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_requests_tenantId_contestantId_idx" ON public.score_governance_requests USING btree ("tenantId", "contestantId");


--
-- Name: score_governance_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_requests_tenantId_idx" ON public.score_governance_requests USING btree ("tenantId");


--
-- Name: score_governance_requests_tenantId_judgeId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_requests_tenantId_judgeId_idx" ON public.score_governance_requests USING btree ("tenantId", "judgeId");


--
-- Name: score_governance_requests_tenantId_scopeType_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_requests_tenantId_scopeType_idx" ON public.score_governance_requests USING btree ("tenantId", "scopeType");


--
-- Name: score_governance_requests_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_governance_requests_tenantId_status_idx" ON public.score_governance_requests USING btree ("tenantId", status);


--
-- Name: score_removal_requests_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_removal_requests_categoryId_idx" ON public.score_removal_requests USING btree ("categoryId");


--
-- Name: score_removal_requests_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX score_removal_requests_status_idx ON public.score_removal_requests USING btree (status);


--
-- Name: score_removal_requests_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_removal_requests_tenantId_categoryId_idx" ON public.score_removal_requests USING btree ("tenantId", "categoryId");


--
-- Name: score_removal_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_removal_requests_tenantId_idx" ON public.score_removal_requests USING btree ("tenantId");


--
-- Name: score_removal_requests_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "score_removal_requests_tenantId_status_idx" ON public.score_removal_requests USING btree ("tenantId", status);


--
-- Name: scores_categoryId_contestantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "scores_categoryId_contestantId_idx" ON public.scores USING btree ("categoryId", "contestantId");


--
-- Name: scores_categoryId_judgeId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "scores_categoryId_judgeId_idx" ON public.scores USING btree ("categoryId", "judgeId");


--
-- Name: scores_isCertified_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "scores_isCertified_categoryId_idx" ON public.scores USING btree ("isCertified", "categoryId");


--
-- Name: scores_tenantId_categoryId_contestantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "scores_tenantId_categoryId_contestantId_idx" ON public.scores USING btree ("tenantId", "categoryId", "contestantId");


--
-- Name: scores_tenantId_categoryId_contestantId_judgeId_criterionId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "scores_tenantId_categoryId_contestantId_judgeId_criterionId_key" ON public.scores USING btree ("tenantId", "categoryId", "contestantId", "judgeId", "criterionId");


--
-- Name: scores_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "scores_tenantId_categoryId_idx" ON public.scores USING btree ("tenantId", "categoryId");


--
-- Name: scores_tenantId_categoryId_judgeId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "scores_tenantId_categoryId_judgeId_idx" ON public.scores USING btree ("tenantId", "categoryId", "judgeId");


--
-- Name: scores_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "scores_tenantId_idx" ON public.scores USING btree ("tenantId");


--
-- Name: scores_tenantId_isCertified_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "scores_tenantId_isCertified_categoryId_idx" ON public.scores USING btree ("tenantId", "isCertified", "categoryId");


--
-- Name: search_analytics_query_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX search_analytics_query_idx ON public.search_analytics USING btree (query);


--
-- Name: search_analytics_searchCount_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "search_analytics_searchCount_idx" ON public.search_analytics USING btree ("searchCount");


--
-- Name: search_history_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "search_history_tenantId_idx" ON public.search_history USING btree ("tenantId");


--
-- Name: search_history_tenantId_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "search_history_tenantId_userId_createdAt_idx" ON public.search_history USING btree ("tenantId", "userId", "createdAt");


--
-- Name: search_history_tenantId_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "search_history_tenantId_userId_idx" ON public.search_history USING btree ("tenantId", "userId");


--
-- Name: search_history_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "search_history_userId_createdAt_idx" ON public.search_history USING btree ("userId", "createdAt");


--
-- Name: system_settings_category_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX system_settings_category_idx ON public.system_settings USING btree (category);


--
-- Name: system_settings_key_tenantId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "system_settings_key_tenantId_key" ON public.system_settings USING btree (key, "tenantId");


--
-- Name: system_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "system_settings_tenantId_idx" ON public.system_settings USING btree ("tenantId");


--
-- Name: tally_master_assignments_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "tally_master_assignments_eventId_idx" ON public.tally_master_assignments USING btree ("eventId");


--
-- Name: tally_master_assignments_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "tally_master_assignments_tenantId_idx" ON public.tally_master_assignments USING btree ("tenantId");


--
-- Name: tally_master_assignments_tenantId_userId_categoryId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "tally_master_assignments_tenantId_userId_categoryId_key" ON public.tally_master_assignments USING btree ("tenantId", "userId", "categoryId");


--
-- Name: tally_master_assignments_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "tally_master_assignments_userId_idx" ON public.tally_master_assignments USING btree ("userId");


--
-- Name: template_criteria_templateId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "template_criteria_templateId_idx" ON public.template_criteria USING btree ("templateId");


--
-- Name: template_criteria_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "template_criteria_tenantId_idx" ON public.template_criteria USING btree ("tenantId");


--
-- Name: template_criteria_tenantId_templateId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "template_criteria_tenantId_templateId_idx" ON public.template_criteria USING btree ("tenantId", "templateId");


--
-- Name: tenants_domain_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX tenants_domain_idx ON public.tenants USING btree (domain);


--
-- Name: tenants_domain_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX tenants_domain_key ON public.tenants USING btree (domain);


--
-- Name: tenants_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "tenants_isActive_idx" ON public.tenants USING btree ("isActive");


--
-- Name: tenants_slug_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX tenants_slug_idx ON public.tenants USING btree (slug);


--
-- Name: tenants_slug_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX tenants_slug_key ON public.tenants USING btree (slug);


--
-- Name: theme_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "theme_settings_tenantId_idx" ON public.theme_settings USING btree ("tenantId");


--
-- Name: theme_settings_tenantId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "theme_settings_tenantId_key" ON public.theme_settings USING btree ("tenantId");


--
-- Name: uniq_idempotency_scope; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX uniq_idempotency_scope ON public.idempotency_records USING btree ("tenantId", "actorType", "actorId", method, "canonicalPath", key);


--
-- Name: user_field_configurations_fieldName_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "user_field_configurations_fieldName_key" ON public.user_field_configurations USING btree ("fieldName");


--
-- Name: users_tenantId_email_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "users_tenantId_email_key" ON public.users USING btree ("tenantId", email);


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: users_tenantId_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "users_tenantId_isActive_idx" ON public.users USING btree ("tenantId", "isActive");


--
-- Name: users_tenantId_role_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "users_tenantId_role_idx" ON public.users USING btree ("tenantId", role);


--
-- Name: webhook_configs_enabled_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX webhook_configs_enabled_idx ON public.webhook_configs USING btree (enabled);


--
-- Name: webhook_configs_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "webhook_configs_tenantId_idx" ON public.webhook_configs USING btree ("tenantId");


--
-- Name: webhook_deliveries_createdAt_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "webhook_deliveries_createdAt_idx" ON public.webhook_deliveries USING btree ("createdAt");


--
-- Name: webhook_deliveries_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX webhook_deliveries_status_idx ON public.webhook_deliveries USING btree (status);


--
-- Name: webhook_deliveries_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "webhook_deliveries_tenantId_idx" ON public.webhook_deliveries USING btree ("tenantId");


--
-- Name: webhook_deliveries_tenantId_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "webhook_deliveries_tenantId_status_idx" ON public.webhook_deliveries USING btree ("tenantId", status);


--
-- Name: webhook_deliveries_tenantId_webhookId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "webhook_deliveries_tenantId_webhookId_idx" ON public.webhook_deliveries USING btree ("tenantId", "webhookId");


--
-- Name: webhook_deliveries_webhookId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "webhook_deliveries_webhookId_idx" ON public.webhook_deliveries USING btree ("webhookId");


--
-- Name: winner_signatures_categoryId_userId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "winner_signatures_categoryId_userId_idx" ON public.winner_signatures USING btree ("categoryId", "userId");


--
-- Name: winner_signatures_tenantId_categoryId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "winner_signatures_tenantId_categoryId_idx" ON public.winner_signatures USING btree ("tenantId", "categoryId");


--
-- Name: winner_signatures_tenantId_categoryId_userId_key; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE UNIQUE INDEX "winner_signatures_tenantId_categoryId_userId_key" ON public.winner_signatures USING btree ("tenantId", "categoryId", "userId");


--
-- Name: winner_signatures_tenantId_contestId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "winner_signatures_tenantId_contestId_idx" ON public.winner_signatures USING btree ("tenantId", "contestId");


--
-- Name: winner_signatures_tenantId_eventId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "winner_signatures_tenantId_eventId_idx" ON public.winner_signatures USING btree ("tenantId", "eventId");


--
-- Name: winner_signatures_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "winner_signatures_tenantId_idx" ON public.winner_signatures USING btree ("tenantId");


--
-- Name: workflow_instances_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX workflow_instances_status_idx ON public.workflow_instances USING btree (status);


--
-- Name: workflow_instances_tenantId_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_instances_tenantId_entityType_entityId_idx" ON public.workflow_instances USING btree ("tenantId", "entityType", "entityId");


--
-- Name: workflow_instances_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_instances_tenantId_idx" ON public.workflow_instances USING btree ("tenantId");


--
-- Name: workflow_step_executions_instanceId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_step_executions_instanceId_idx" ON public.workflow_step_executions USING btree ("instanceId");


--
-- Name: workflow_step_executions_status_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX workflow_step_executions_status_idx ON public.workflow_step_executions USING btree (status);


--
-- Name: workflow_step_executions_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_step_executions_tenantId_idx" ON public.workflow_step_executions USING btree ("tenantId");


--
-- Name: workflow_step_executions_tenantId_instanceId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_step_executions_tenantId_instanceId_idx" ON public.workflow_step_executions USING btree ("tenantId", "instanceId");


--
-- Name: workflow_steps_templateId_stepOrder_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_steps_templateId_stepOrder_idx" ON public.workflow_steps USING btree ("templateId", "stepOrder");


--
-- Name: workflow_steps_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_steps_tenantId_idx" ON public.workflow_steps USING btree ("tenantId");


--
-- Name: workflow_steps_tenantId_templateId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_steps_tenantId_templateId_idx" ON public.workflow_steps USING btree ("tenantId", "templateId");


--
-- Name: workflow_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_templates_tenantId_idx" ON public.workflow_templates USING btree ("tenantId");


--
-- Name: workflow_templates_tenantId_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_templates_tenantId_isActive_idx" ON public.workflow_templates USING btree ("tenantId", "isActive");


--
-- Name: workflow_templates_type_isActive_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_templates_type_isActive_idx" ON public.workflow_templates USING btree (type, "isActive");


--
-- Name: workflow_transitions_fromStepId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_transitions_fromStepId_idx" ON public.workflow_transitions USING btree ("fromStepId");


--
-- Name: workflow_transitions_tenantId_fromStepId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_transitions_tenantId_fromStepId_idx" ON public.workflow_transitions USING btree ("tenantId", "fromStepId");


--
-- Name: workflow_transitions_tenantId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_transitions_tenantId_idx" ON public.workflow_transitions USING btree ("tenantId");


--
-- Name: workflow_transitions_toStepId_idx; Type: INDEX; Schema: public; Owner: event_manager
--

CREATE INDEX "workflow_transitions_toStepId_idx" ON public.workflow_transitions USING btree ("toStepId");


--
-- Name: activity_logs activity_logs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT "activity_logs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: activity_logs activity_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT "activity_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: archived_events archived_events_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.archived_events
    ADD CONSTRAINT "archived_events_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assignments assignments_assignedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT "assignments_assignedBy_fkey" FOREIGN KEY ("assignedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assignments assignments_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT "assignments_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assignments assignments_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT "assignments_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assignments assignments_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT "assignments_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assignments assignments_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT "assignments_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: auditor_assignments auditor_assignments_assignedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.auditor_assignments
    ADD CONSTRAINT "auditor_assignments_assignedBy_fkey" FOREIGN KEY ("assignedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: auditor_assignments auditor_assignments_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.auditor_assignments
    ADD CONSTRAINT "auditor_assignments_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: auditor_assignments auditor_assignments_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.auditor_assignments
    ADD CONSTRAINT "auditor_assignments_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: auditor_assignments auditor_assignments_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.auditor_assignments
    ADD CONSTRAINT "auditor_assignments_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: auditor_assignments auditor_assignments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.auditor_assignments
    ADD CONSTRAINT "auditor_assignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: category_certifications category_certifications_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_certifications
    ADD CONSTRAINT "category_certifications_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: category_contestants category_contestants_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_contestants
    ADD CONSTRAINT "category_contestants_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: category_contestants category_contestants_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_contestants
    ADD CONSTRAINT "category_contestants_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: category_judges category_judges_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_judges
    ADD CONSTRAINT "category_judges_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: category_judges category_judges_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.category_judges
    ADD CONSTRAINT "category_judges_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contest_certifications contest_certifications_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contest_certifications
    ADD CONSTRAINT "contest_certifications_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contest_certifications contest_certifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contest_certifications
    ADD CONSTRAINT "contest_certifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contest_contestants contest_contestants_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contest_contestants
    ADD CONSTRAINT "contest_contestants_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contest_contestants contest_contestants_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contest_contestants
    ADD CONSTRAINT "contest_contestants_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contest_judges contest_judges_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contest_judges
    ADD CONSTRAINT "contest_judges_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contest_judges contest_judges_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contest_judges
    ADD CONSTRAINT "contest_judges_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contests contests_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.contests
    ADD CONSTRAINT "contests_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: criteria criteria_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.criteria
    ADD CONSTRAINT "criteria_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: custom_field_values custom_field_values_customFieldId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT "custom_field_values_customFieldId_fkey" FOREIGN KEY ("customFieldId") REFERENCES public.custom_fields(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deduction_approvals deduction_approvals_requestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.deduction_approvals
    ADD CONSTRAINT "deduction_approvals_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES public.deduction_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deduction_requests deduction_requests_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.deduction_requests
    ADD CONSTRAINT "deduction_requests_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deduction_requests deduction_requests_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.deduction_requests
    ADD CONSTRAINT "deduction_requests_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deduction_requests deduction_requests_requestedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.deduction_requests
    ADD CONSTRAINT "deduction_requests_requestedById_fkey" FOREIGN KEY ("requestedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: emcee_scripts emcee_scripts_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.emcee_scripts
    ADD CONSTRAINT "emcee_scripts_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: emcee_scripts emcee_scripts_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.emcee_scripts
    ADD CONSTRAINT "emcee_scripts_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: emcee_scripts emcee_scripts_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.emcee_scripts
    ADD CONSTRAINT "emcee_scripts_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: event_templates event_templates_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.event_templates
    ADD CONSTRAINT "event_templates_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: judge_certifications judge_certifications_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_certifications
    ADD CONSTRAINT "judge_certifications_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_certifications judge_certifications_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_certifications
    ADD CONSTRAINT "judge_certifications_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_comments judge_comments_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_comments
    ADD CONSTRAINT "judge_comments_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_comments judge_comments_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_comments
    ADD CONSTRAINT "judge_comments_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_comments judge_comments_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_comments
    ADD CONSTRAINT "judge_comments_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_contestant_certifications judge_contestant_certifications_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_contestant_certifications
    ADD CONSTRAINT "judge_contestant_certifications_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_contestant_certifications judge_contestant_certifications_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_contestant_certifications
    ADD CONSTRAINT "judge_contestant_certifications_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_contestant_certifications judge_contestant_certifications_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_contestant_certifications
    ADD CONSTRAINT "judge_contestant_certifications_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_score_removal_requests judge_score_removal_requests_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_score_removal_requests
    ADD CONSTRAINT "judge_score_removal_requests_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_score_removal_requests judge_score_removal_requests_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_score_removal_requests
    ADD CONSTRAINT "judge_score_removal_requests_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_score_removal_requests judge_score_removal_requests_scoreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_score_removal_requests
    ADD CONSTRAINT "judge_score_removal_requests_scoreId_fkey" FOREIGN KEY ("scoreId") REFERENCES public.scores(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_uncertification_requests judge_uncertification_requests_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_uncertification_requests
    ADD CONSTRAINT "judge_uncertification_requests_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_uncertification_requests judge_uncertification_requests_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_uncertification_requests
    ADD CONSTRAINT "judge_uncertification_requests_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: judge_uncertification_requests judge_uncertification_requests_requestedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.judge_uncertification_requests
    ADD CONSTRAINT "judge_uncertification_requests_requestedBy_fkey" FOREIGN KEY ("requestedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notification_digests notification_digests_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.notification_digests
    ADD CONSTRAINT "notification_digests_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT "notification_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: overall_deductions overall_deductions_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.overall_deductions
    ADD CONSTRAINT "overall_deductions_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: overall_deductions overall_deductions_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.overall_deductions
    ADD CONSTRAINT "overall_deductions_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: password_histories password_histories_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.password_histories
    ADD CONSTRAINT "password_histories_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "push_subscriptions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "push_subscriptions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rate_limit_configs rate_limit_configs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.rate_limit_configs
    ADD CONSTRAINT "rate_limit_configs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rate_limit_configs rate_limit_configs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.rate_limit_configs
    ADD CONSTRAINT "rate_limit_configs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: report_instances report_instances_generatedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.report_instances
    ADD CONSTRAINT "report_instances_generatedById_fkey" FOREIGN KEY ("generatedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: review_contestant_certifications review_contestant_certifications_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.review_contestant_certifications
    ADD CONSTRAINT "review_contestant_certifications_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review_contestant_certifications review_contestant_certifications_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.review_contestant_certifications
    ADD CONSTRAINT "review_contestant_certifications_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review_contestant_certifications review_contestant_certifications_reviewedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.review_contestant_certifications
    ADD CONSTRAINT "review_contestant_certifications_reviewedBy_fkey" FOREIGN KEY ("reviewedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: review_judge_score_certifications review_judge_score_certifications_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.review_judge_score_certifications
    ADD CONSTRAINT "review_judge_score_certifications_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review_judge_score_certifications review_judge_score_certifications_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.review_judge_score_certifications
    ADD CONSTRAINT "review_judge_score_certifications_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review_judge_score_certifications review_judge_score_certifications_reviewedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.review_judge_score_certifications
    ADD CONSTRAINT "review_judge_score_certifications_reviewedBy_fkey" FOREIGN KEY ("reviewedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_assignments role_assignments_assignedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT "role_assignments_assignedBy_fkey" FOREIGN KEY ("assignedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_assignments role_assignments_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT "role_assignments_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_assignments role_assignments_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT "role_assignments_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_assignments role_assignments_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT "role_assignments_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_assignments role_assignments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT "role_assignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: saved_searches saved_searches_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT "saved_searches_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_comments score_comments_criterionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_comments
    ADD CONSTRAINT "score_comments_criterionId_fkey" FOREIGN KEY ("criterionId") REFERENCES public.criteria(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_comments score_comments_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_comments
    ADD CONSTRAINT "score_comments_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_comments score_comments_scoreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_comments
    ADD CONSTRAINT "score_comments_scoreId_fkey" FOREIGN KEY ("scoreId") REFERENCES public.scores(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_files score_files_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_files
    ADD CONSTRAINT "score_files_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_files score_files_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_files
    ADD CONSTRAINT "score_files_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_files score_files_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_files
    ADD CONSTRAINT "score_files_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_files score_files_uploadedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_files
    ADD CONSTRAINT "score_files_uploadedById_fkey" FOREIGN KEY ("uploadedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: score_governance_approvals score_governance_approvals_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_approvals
    ADD CONSTRAINT "score_governance_approvals_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_governance_approvals score_governance_approvals_requestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_approvals
    ADD CONSTRAINT "score_governance_approvals_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES public.score_governance_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_governance_requests score_governance_requests_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_requests
    ADD CONSTRAINT "score_governance_requests_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: score_governance_requests score_governance_requests_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_requests
    ADD CONSTRAINT "score_governance_requests_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: score_governance_requests score_governance_requests_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_requests
    ADD CONSTRAINT "score_governance_requests_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: score_governance_requests score_governance_requests_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_requests
    ADD CONSTRAINT "score_governance_requests_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: score_governance_requests score_governance_requests_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_requests
    ADD CONSTRAINT "score_governance_requests_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: score_governance_requests score_governance_requests_requestedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_governance_requests
    ADD CONSTRAINT "score_governance_requests_requestedById_fkey" FOREIGN KEY ("requestedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_removal_requests score_removal_requests_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_removal_requests
    ADD CONSTRAINT "score_removal_requests_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_removal_requests score_removal_requests_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_removal_requests
    ADD CONSTRAINT "score_removal_requests_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_removal_requests score_removal_requests_requestedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.score_removal_requests
    ADD CONSTRAINT "score_removal_requests_requestedBy_fkey" FOREIGN KEY ("requestedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scores scores_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT "scores_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scores scores_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT "scores_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scores scores_criterionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT "scores_criterionId_fkey" FOREIGN KEY ("criterionId") REFERENCES public.criteria(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scores scores_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT "scores_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: search_history search_history_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT "search_history_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: system_settings system_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT "system_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tally_master_assignments tally_master_assignments_assignedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.tally_master_assignments
    ADD CONSTRAINT "tally_master_assignments_assignedBy_fkey" FOREIGN KEY ("assignedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tally_master_assignments tally_master_assignments_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.tally_master_assignments
    ADD CONSTRAINT "tally_master_assignments_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tally_master_assignments tally_master_assignments_contestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.tally_master_assignments
    ADD CONSTRAINT "tally_master_assignments_contestId_fkey" FOREIGN KEY ("contestId") REFERENCES public.contests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tally_master_assignments tally_master_assignments_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.tally_master_assignments
    ADD CONSTRAINT "tally_master_assignments_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tally_master_assignments tally_master_assignments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.tally_master_assignments
    ADD CONSTRAINT "tally_master_assignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: template_criteria template_criteria_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.template_criteria
    ADD CONSTRAINT "template_criteria_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.category_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_contestantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_contestantId_fkey" FOREIGN KEY ("contestantId") REFERENCES public.contestants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_judgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_judgeId_fkey" FOREIGN KEY ("judgeId") REFERENCES public.judges(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: event_manager
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict APHSQtNhBEQ7ZH5xapzdYwctPOtCEEVjaJqFzl1P9odjTONZtWpJBDdjYI6EA2c

